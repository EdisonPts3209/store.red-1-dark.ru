#!/bin/bash

# 🚀 БЫСТРЫЙ СТАРТ RED1DARK STUDIO v2.0
# Запустите этот скрипт для локального тестирования

echo "🚀 Red1dark Studio - Инициализация..."
echo ""

# Проверка Python
if ! command -v python &> /dev/null; then
    echo "❌ Python не установлен! Установите Python 3.8+"
    exit 1
fi

echo "✅ Python найден: $(python --version)"
echo ""

# Установка зависимостей
echo "📦 Установка зависимостей..."
pip install -r requirements.txt

if [ $? -ne 0 ]; then
    echo "❌ Ошибка при установке зависимостей!"
    exit 1
fi

echo "✅ Зависимости установлены"
echo ""

# Копирование .env если не существует
if [ ! -f .env ]; then
    echo "📝 Создание .env файла..."
    cp .env.example .env
    echo "✅ Файл .env создан. Обновите OAuth ключи если нужны."
else
    echo "✅ Файл .env уже существует"
fi

echo ""
echo "🎉 ВСЁ ГОТОВО! Запуск приложения..."
echo ""
echo "Откройте браузер на: http://localhost:5000"
echo ""
echo "📋 ТЕСТОВЫЕ АККАУНТЫ:"
echo "  Email: test@gmail.com"
echo "  Password: password123"
echo ""
echo "Нажмите Ctrl+C для остановки сервера"
echo ""

python app.py
