from flask import Flask, render_template, request, redirect, url_for, session, jsonify, flash
import json
import os
from datetime import datetime, timedelta
from functools import wraps
from dotenv import load_dotenv
from werkzeug.security import generate_password_hash, check_password_hash
from auth import generate_otp, OTP_STORAGE, send_otp_email, is_rate_limited, log_attempt, verify_otp, verify_captcha

# Загрузить переменные окружения из .env
load_dotenv()

basedir = os.path.abspath(os.path.dirname(__file__))
app = Flask(__name__, static_url_path='/static')
app.secret_key = os.getenv('SECRET_KEY', 'dev-secret-key-change-in-production')

# Пути к файлам данных
DATA_DIR = 'data'
USERS_FILE = os.path.join(DATA_DIR, 'users.json')
SERVICES_FILE = os.path.join(DATA_DIR, 'services.json')
REQUESTS_FILE = os.path.join(DATA_DIR, 'requests.json')
SETTINGS_FILE = os.path.join(DATA_DIR, 'settings.json')

# Telegram Bot настройки
TELEGRAM_BOT_TOKEN = os.environ.get('TELEGRAM_BOT_TOKEN', '')  # Токен из переменных окружения

# Создание директории для данных
os.makedirs(DATA_DIR, exist_ok=True)

# Инициализация файлов данных
def init_data_files():
    if not os.path.exists(USERS_FILE):
        with open(USERS_FILE, 'w', encoding='utf-8') as f:
            json.dump({}, f, ensure_ascii=False, indent=2)
    
    if not os.path.exists(SERVICES_FILE):
        default_services = {
            "1": {
                "id": "1",
                "category": "telegram",
                "name": "🤖 Лёгкий Telegram-бот",
                "description": "Бот с кнопками (Информация, Контакты, Заявка)",
                "price": 500,
                "duration": "5 дней",
                "icon": "🤖",
                "active": True
            },
            "2": {
                "id": "2",
                "category": "telegram",
                "name": "🤖 Средний Telegram-бот",
                "description": "Бот с заявками, JSON/БД, историей, уведомлениями админу",
                "price": 1000,
                "duration": "15 дней",
                "icon": "🤖",
                "active": True
            },
            "3": {
                "id": "3",
                "category": "telegram",
                "name": "🤖 Сложный Telegram-бот (CRM)",
                "description": "Бот-CRM: заявки, статусы, роли, БД, админ-панель, аналитика",
                "price": 5000,
                "duration": "30 дней",
                "icon": "🤖",
                "active": True
            },
            "4": {
                "id": "4",
                "category": "web",
                "name": "🌐 Визитка",
                "description": "Одна страница: описание, фото, соцсети, форма связи",
                "price": 500,
                "duration": "10 дней",
                "icon": "🌐",
                "active": True
            },
            "5": {
                "id": "5",
                "category": "web",
                "name": "🌐 Лендинг",
                "description": "Продающая страница с блоками, анимациями, формой заявки",
                "price": 1000,
                "duration": "15 дней",
                "icon": "🌐",
                "active": True
            },
            "6": {
                "id": "6",
                "category": "web",
                "name": "🌐 Мини-портфолио / Мини-панель",
                "description": "Личный кабинет на Flask: вход, профиль, загрузка аватара",
                "price": 2000,
                "duration": "20 дней",
                "icon": "🌐",
                "active": True
            },
            "7": {
                "id": "7",
                "category": "oauth",
                "name": "🔐 OAuth интеграция",
                "description": "Подключение VK или Telegram OAuth (за один сервис)",
                "price": 500,
                "duration": "1-2 дня",
                "icon": "🔐",
                "active": True
            },
            "8": {
                "id": "8",
                "category": "additional",
                "name": "🔗 Создание API",
                "description": "API для заявок: /create, /list, /update",
                "price": 500,
                "duration": "5 дней",
                "icon": "🔗",
                "active": True
            },
            "9": {
                "id": "9",
                "category": "additional",
                "name": "💾 Создание базы данных (SQLite)",
                "description": "Таблицы users, requests, services с индексами",
                "price": 500,
                "duration": "2-3 дня",
                "icon": "💾",
                "active": True
            }
        }
        with open(SERVICES_FILE, 'w', encoding='utf-8') as f:
            json.dump(default_services, f, ensure_ascii=False, indent=2)
    
    if not os.path.exists(REQUESTS_FILE):
        with open(REQUESTS_FILE, 'w', encoding='utf-8') as f:
            json.dump({}, f, ensure_ascii=False, indent=2)
    
    if not os.path.exists(SETTINGS_FILE):
        default_settings = {
            "store_name": "Red1dark Studio",
            "owner": "Red1dark",
            "logo": "🎨 Red1dark Studio",
            "contacts": {
                "telegram": "@red1dark",
                "email": "info@red-1-dark.ru"
            },
            "system_account": {
                "email": "store.red-1-dark.ru@red-1-dark.ru",
                "role": "admin",
                "description": "Главный администратор системы"
            },
            "payment_methods": {
                "sbp": {
                    "enabled": True,
                    "name": "СБП (QR / Ссылка)",
                    "description": "Быстрая оплата через систему быстрых платежей"
                },
                "alphabank": {
                    "enabled": True,
                    "name": "Альфа-Банк эквайринг",
                    "description": "Платёжные ссылки для самозанятых"
                }
            },
            "email_whitelist": ["vk.com", "gmail.com", "mail.ru", "yandex.ru"],
            "otp_enabled": True,
            "otp_timeout": 600,
            "notifications": True,
            "telegram_bot": ""
        }
        with open(SETTINGS_FILE, 'w', encoding='utf-8') as f:
            json.dump(default_settings, f, ensure_ascii=False, indent=2)

init_data_files()

# Декораторы
def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            flash('Необходимо войти в систему', 'warning')
            return redirect(url_for('index'))
        return f(*args, **kwargs)
    return decorated_function

def seller_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            flash('Необходимо войти в систему', 'warning')
            return redirect(url_for('index'))
        
        users = load_json(USERS_FILE)
        user = users.get(session['user_id'])
        
        if not user or not user.get('is_seller'):
            flash('Доступ запрещён', 'danger')
            return redirect(url_for('index'))
        
        return f(*args, **kwargs)
    return decorated_function

# Утилиты
def load_json(filepath):
    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            return json.load(f)
    except:
        return {}

def save_json(filepath, data):
    with open(filepath, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

def get_current_user():
    if 'user_id' in session:
        users = load_json(USERS_FILE)
        return users.get(session['user_id'])
    return None

# Функция для отправки Telegram уведомлений
def send_telegram_notification(telegram_id, message):
    """Отправка уведомления через Telegram бота"""
    if not TELEGRAM_BOT_TOKEN:
        return False
    
    try:
        import requests
        url = f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendMessage"
        
        data = {
            "chat_id": telegram_id,
            "text": message,
            "parse_mode": "Markdown"
        }
        
        response = requests.post(url, json=data, timeout=5)
        return response.json().get('ok', False)
    except:
        return False

# Главная страница
@app.route('/')
def index():
    services = load_json(SERVICES_FILE)
    active_services = {k: v for k, v in services.items() if v.get('active', True)}
    user = get_current_user()
    settings = load_json(SETTINGS_FILE)
    
    return render_template('index.html', 
                         services=list(active_services.values())[:6],
                         user=user,
                         settings=settings)

# Каталог услуг
@app.route('/services')
def services():
    all_services = load_json(SERVICES_FILE)
    active_services = {k: v for k, v in all_services.items() if v.get('active', True)}
    
    category = request.args.get('category', 'all')
    
    if category != 'all':
        filtered = {k: v for k, v in active_services.items() if v.get('category') == category}
    else:
        filtered = active_services
    
    user = get_current_user()
    settings = load_json(SETTINGS_FILE)
    
    return render_template('services.html',
                         services=list(filtered.values()),
                         category=category,
                         user=user,
                         settings=settings)

# Корзина
@app.route('/cart')
def cart():
    cart_items = session.get('cart', [])
    services = load_json(SERVICES_FILE)
    
    cart_services = []
    total = 0
    
    for item_id in cart_items:
        if item_id in services:
            service = services[item_id]
            cart_services.append(service)
            total += service.get('price', 0)
    
    user = get_current_user()
    settings = load_json(SETTINGS_FILE)
    
    return render_template('cart.html',
                         cart_services=cart_services,
                         total=total,
                         user=user,
                         settings=settings)

# Добавить в корзину
@app.route('/cart/add/<service_id>')
def add_to_cart(service_id):
    cart = session.get('cart', [])
    
    if service_id not in cart:
        cart.append(service_id)
        session['cart'] = cart
        flash('Услуга добавлена в корзину', 'success')
    else:
        flash('Услуга уже в корзине', 'info')
    
    return redirect(request.referrer or url_for('services'))

# Удалить из корзины
@app.route('/cart/remove/<service_id>')
def remove_from_cart(service_id):
    cart = session.get('cart', [])
    
    if service_id in cart:
        cart.remove(service_id)
        session['cart'] = cart
        flash('Услуга удалена из корзины', 'success')
    
    return redirect(url_for('cart'))

# Форма заявки
@app.route('/request', methods=['GET', 'POST'])
@login_required
def create_request():
    if request.method == 'POST':
        user = get_current_user()
        
        request_data = {
            'id': str(int(datetime.now().timestamp())),
            'user_id': session['user_id'],
            'username': user.get('username', 'Гость'),
            'service_id': request.form.get('service_id'),
            'service_name': request.form.get('service_name'),
            'description': request.form.get('description'),
            'created_at': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            'status': 'pending_payment',
            'priority': 'normal'
        }
        
        requests_data = load_json(REQUESTS_FILE)
        requests_data[request_data['id']] = request_data
        save_json(REQUESTS_FILE, requests_data)
        
        # Очистить корзину
        session['cart'] = []
        
        flash('Заявка отправлена! Ожидайте информацию об оплате.', 'success')
        return redirect(url_for('profile_requests'))
    
    # GET request
    service_id = request.args.get('service_id')
    services_data = load_json(SERVICES_FILE)
    
    selected_service = None
    if service_id and service_id in services_data:
        selected_service = services_data[service_id]
    
    cart_items = session.get('cart', [])
    cart_services = [services_data[sid] for sid in cart_items if sid in services_data]
    
    user = get_current_user()
    settings = load_json(SETTINGS_FILE)
    
    return render_template('request.html',
                         selected_service=selected_service,
                         cart_services=cart_services,
                         user=user,
                         settings=settings)

# Демо-авторизация (для разработки)
# ============ АВТОРИЗАЦИЯ И РЕГИСТРАЦИя ============

@app.route('/register', methods=['GET', 'POST'])
def register():
    """Регистрация нового пользователя"""
    if request.method == 'POST':
        email = request.form.get('email', '').lower()
        username = request.form.get('username', '')
        password = request.form.get('password', '')
        password_confirm = request.form.get('password_confirm', '')
        
        # Валидация
        if not email or not username or not password:
            flash('Все поля обязательны', 'danger')
            return redirect(url_for('register'))
        
        if password != password_confirm:
            flash('Пароли не совпадают', 'danger')
            return redirect(url_for('register'))
        
        if len(password) < 6:
            flash('Пароль должен быть минимум 6 символов', 'danger')
            return redirect(url_for('register'))
        
        # Проверка доставчика email
        domain = email.split('@')[1] if '@' in email else ''
        allowed_domains = ['vk.com', 'gmail.com', 'mail.ru', 'yandex.ru']
        
        if domain not in allowed_domains:
            flash(f'Домен {domain} не разрешён. Используйте: {", ".join(allowed_domains)}', 'danger')
            return redirect(url_for('register'))
        
        users = load_json(USERS_FILE)
        
        # Проверка уникальности
        for u in users.values():
            if u.get('email') == email:
                flash('Пользователь с таким email уже существует', 'danger')
                return redirect(url_for('register'))
            if u.get('username') == username:
                flash('Пользователь с таким username уже существует', 'danger')
                return redirect(url_for('register'))
        
        # Создание еользователя
        user_id = str(int(max([int(k) for k in users.keys()], default=0)) + 1)
        users[user_id] = {
            'id': user_id,
            'email': email,
            'username': username,
            'name': username,
            'password_hash': generate_password_hash(password),
            'role': 'buyer',
            'avatar': '',
            'description': '',
            'links': [],
            'created_at': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            'email_verified': True,
            'blocked': False,
            'oauth_providers': {}
        }
        save_json(USERS_FILE, users)
        
        session['user_id'] = user_id
        flash(f'МОлодец! Вы зарегистрировались', 'success')
        return redirect(url_for('profile'))
    
    settings = load_json(SETTINGS_FILE)
    return render_template('register.html', settings=settings)


@app.route('/login', methods=['GET', 'POST'])
def login():
    """Вход по email и паролю"""
    if request.method == 'POST':
        email = request.form.get('email', '').lower()
        password = request.form.get('password', '')
        honeypot = request.form.get('hp_field', '')
        form_ts = request.form.get('form_ts')
        recaptcha_token = request.form.get('g-recaptcha-response', '')

        client_ip = request.remote_addr or 'unknown'

        # Honeypot: если поле заполнено - бот
        if honeypot:
            flash('Подозрительная активность обнаружена', 'danger')
            return redirect(url_for('login'))

        # Таймер формы: если форма отправлена очень быстро — бот
        try:
            if form_ts:
                sent_at = int(form_ts)
                elapsed = (datetime.utcnow().timestamp()*1000) - sent_at
                if elapsed < 2000:  # менее 2 секунд
                    flash('Подозрительная активность: форма отправлена слишком быстро', 'danger')
                    return redirect(url_for('login'))
        except Exception:
            pass

        # Проверка reCAPTCHA если настроен
        if recaptcha_token and not verify_captcha(recaptcha_token):
            flash('Проверка reCAPTCHA не пройдена', 'danger')
            return redirect(url_for('login'))
        
        users = load_json(USERS_FILE)
        user = None
        user_id = None
        
        # Поиск пользователя по email
        for uid, u in users.items():
            if u.get('email') == email:
                user = u
                user_id = uid
                break
        
        if not user:
            flash('Пользователь не найден', 'danger')
            return redirect(url_for('login'))
        
        if user.get('blocked'):
            flash('Ваш аккаунт заблокирован', 'danger')
            return redirect(url_for('login'))

        # Если нажали кнопку "Отправить код" или запрос пришёл на отправку OTP
        if 'send_otp' in request.form:
            # rate limit
            if is_rate_limited(client_ip, 'send_otp'):
                flash('Слишком много запросов. Попробуйте позже.', 'danger')
                return redirect(url_for('login'))

            otp = generate_otp()
            expiry = int(os.getenv('OTP_EXPIRY', '600'))
            OTP_STORAGE[email] = {'code': otp, 'expires_at': datetime.now() + timedelta(seconds=expiry)}
            send_otp_email(email, otp)
            log_attempt(client_ip, 'send_otp')
            flash('Одноразовый код отправлен на вашу почту (если почта настроена).', 'info')
            return redirect(url_for('login'))

        # Если пришёл вход по коду
        if 'otp_code' in request.form and request.form.get('otp_code'):
            if is_rate_limited(client_ip, 'otp_verify'):
                flash('Слишком много попыток проверки кода. Попробуйте позже.', 'danger')
                return redirect(url_for('login'))

            otp_code = request.form.get('otp_code')
            ok, msg = verify_otp(email, otp_code)
            log_attempt(client_ip, 'otp_verify')
            if not ok:
                flash(msg, 'danger')
                return redirect(url_for('login'))

            # Логин по OTP
            session['user_id'] = user_id
            flash(f'Добро пожаловать, {user.get("username", "Гост") }!', 'success')
            return redirect(url_for('profile'))

        # Падение пароля: rate limit и проверка
        if is_rate_limited(client_ip, 'password'):
            flash('Слишком много попыток входа. Попробуйте позже.', 'danger')
            return redirect(url_for('login'))

        if not check_password_hash(user.get('password_hash', ''), password):
            log_attempt(client_ip, 'password')
            flash('Неверный пароль', 'danger')
            return redirect(url_for('login'))
        
        # Успешный вход
        session['user_id'] = user_id
        flash(f'Добро пожаловать, {user.get("username", "Гост")}!', 'success')
        return redirect(url_for('profile'))
    
    settings = load_json(SETTINGS_FILE)
    return render_template('login.html', settings=settings)


@app.route('/logout')
def logout():
    """Выход из системы"""
    session.clear()
    flash('Вы вышли из системы', 'info')
    return redirect(url_for('index'))

# ============ OAuth ИНТЕГРАЦИИ ============

@app.route('/auth/vk/callback')
def auth_vk_callback():
    """Callback для VK OAuth"""
    from oauth_handlers import exchange_vk_code, get_vk_user
    
    code = request.args.get('code')
    error = request.args.get('error')
    
    if error:
        flash(f'Ошибка VK OAuth: {error}', 'danger')
        return redirect(url_for('login'))
    
    if not code:
        flash('Код OAuth не получен', 'danger')
        return redirect(url_for('login'))
    
    redirect_uri = url_for('auth_vk_callback', _external=True)
    access_token, err = exchange_vk_code(code, redirect_uri)
    
    if err:
        flash(f'Ошибка обмена кода: {err}', 'danger')
        return redirect(url_for('login'))
    
    vk_user, err = get_vk_user(access_token)
    if err:
        flash(f'Ошибка получения данных VK: {err}', 'danger')
        return redirect(url_for('login'))
    
    # Создаём и логиним пользователя
    vk_id = str(vk_user.get('id'))
    vk_name = f"{vk_user.get('first_name', '')} {vk_user.get('last_name', '')}".strip()
    email = f"{vk_id}@vk.com"  # Синтетический email VK
    
    users = load_json(USERS_FILE)
    user_id = None
    
    # Ищем по VK id
    for uid, u in users.items():
        if u.get('oauth_providers', {}).get('vk') == vk_id:
            user_id = uid
            break
    
    # Если не найдён — создаём
    if not user_id:
        user_id = str(len(users) + 1)
        users[user_id] = {
            'id': user_id,
            'email': email,
            'username': vk_name or f'VK_{vk_id}',
            'name': vk_name,
            'password_hash': '',
            'role': 'buyer',
            'avatar': vk_user.get('photo_100', ''),
            'description': '',
            'links': [],
            'created_at': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            'email_verified': True,
            'blocked': False,
            'oauth_providers': {'vk': vk_id}
        }
        save_json(USERS_FILE, users)
    else:
        # Обновляем данные
        users[user_id]['oauth_providers'] = {'vk': vk_id}
        users[user_id]['avatar'] = vk_user.get('photo_100', users[user_id].get('avatar', ''))
        save_json(USERS_FILE, users)
    
    session['user_id'] = user_id
    flash(f'Добро пожаловать, {users[user_id].get("username")}!', 'success')
    return redirect(url_for('profile'))


@app.route('/auth/yandex/callback')
def auth_yandex_callback():
    """Callback для Yandex OAuth"""
    from oauth_handlers import exchange_yandex_code, get_yandex_user
    
    code = request.args.get('code')
    error = request.args.get('error')
    
    if error:
        flash(f'Ошибка Yandex OAuth: {error}', 'danger')
        return redirect(url_for('login'))
    
    if not code:
        flash('Код OAuth не получен', 'danger')
        return redirect(url_for('login'))
    
    redirect_uri = url_for('auth_yandex_callback', _external=True)
    access_token, err = exchange_yandex_code(code, redirect_uri)
    
    if err:
        flash(f'Ошибка обмена кода: {err}', 'danger')
        return redirect(url_for('login'))
    
    yandex_user, err = get_yandex_user(access_token)
    if err:
        flash(f'Ошибка получения данных Yandex: {err}', 'danger')
        return redirect(url_for('login'))
    
    # Создаём и логиним пользователя
    yandex_id = str(yandex_user.get('id'))
    yandex_name = yandex_user.get('display_name', yandex_user.get('login', ''))
    email = yandex_user.get('default_email', f"{yandex_id}@yandex.ru")
    
    users = load_json(USERS_FILE)
    user_id = None
    
    # Ищем по Yandex id или email
    for uid, u in users.items():
        if u.get('oauth_providers', {}).get('yandex') == yandex_id or u.get('email') == email:
            user_id = uid
            break
    
    # Если не найдён — создаём
    if not user_id:
        user_id = str(len(users) + 1)
        users[user_id] = {
            'id': user_id,
            'email': email,
            'username': yandex_name or f'Yandex_{yandex_id}',
            'name': yandex_name,
            'password_hash': '',
            'role': 'buyer',
            'avatar': yandex_user.get('pic_avatar', {}).get('pic_50x50', ''),
            'description': '',
            'links': [],
            'created_at': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            'email_verified': True,
            'blocked': False,
            'oauth_providers': {'yandex': yandex_id}
        }
        save_json(USERS_FILE, users)
    else:
        # Обновляем данные
        users[user_id]['oauth_providers'] = {'yandex': yandex_id}
        save_json(USERS_FILE, users)
    
    session['user_id'] = user_id
    flash(f'Добро пожаловать, {users[user_id].get("username")}!', 'success')
    return redirect(url_for('profile'))


@app.route('/auth/telegram', methods=['POST'])
def auth_telegram():
    """Обработчик Telegram Widget Login"""
    from oauth_handlers import verify_telegram_widget
    
    # Получаем данные из Telegram Widget
    auth_data = {
        'id': request.json.get('id'),
        'first_name': request.json.get('first_name'),
        'last_name': request.json.get('last_name'),
        'username': request.json.get('username'),
        'photo_url': request.json.get('photo_url'),
        'auth_date': request.json.get('auth_date'),
        'hash': request.json.get('hash')
    }
    
    # Проверяем подпись
    ok, err = verify_telegram_widget(auth_data)
    if not ok:
        return jsonify({'success': False, 'error': err or 'Неверная подпись'}), 401
    
    # Создаём/обновляем пользователя
    telegram_id = str(auth_data.get('id'))
    telegram_name = f"{auth_data.get('first_name', '')} {auth_data.get('last_name', '')}".strip()
    email = f"{telegram_id}@telegram.org"
    
    users = load_json(USERS_FILE)
    user_id = None
    
    # Ищем по Telegram id
    for uid, u in users.items():
        if u.get('oauth_providers', {}).get('telegram') == telegram_id:
            user_id = uid
            break
    
    # Если не найдён — создаём
    if not user_id:
        user_id = str(len(users) + 1)
        users[user_id] = {
            'id': user_id,
            'email': email,
            'username': auth_data.get('username') or telegram_name or f'Telegram_{telegram_id}',
            'name': telegram_name,
            'password_hash': '',
            'role': 'buyer',
            'avatar': auth_data.get('photo_url', ''),
            'description': '',
            'links': [],
            'created_at': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            'email_verified': False,
            'blocked': False,
            'oauth_providers': {'telegram': telegram_id}
        }
        save_json(USERS_FILE, users)
    else:
        # Обновляем данные
        users[user_id]['oauth_providers'] = {'telegram': telegram_id}
        save_json(USERS_FILE, users)
    
    session['user_id'] = user_id
    return jsonify({'success': True, 'user_id': user_id})

# ============ АДМИН-ПАНЕЛЬ: УПРАВЛЕНИЕ РОЛЯМИ ============


@app.route('/admin/roles', methods=['GET', 'POST'])
def admin_roles():
    """Управление ролями пользователей"""
    user = get_current_user()
    if not user:
        return redirect(url_for('login'))
    
    user_role = user.get('role', 'guest')
    user_id = session.get('user_id')
    
    # Ою owner, system_admin и admin могут управлять ролями
    if user_role not in ['owner', 'system_admin', 'admin']:
        flash('Недостаточно прав', 'danger')
        return redirect(url_for('index'))
    
    users = load_json(USERS_FILE)
    
    if request.method == 'POST':
        action = request.form.get('action')
        target_user_id = request.form.get('user_id')
        
        if action == 'assign_role':
            new_role = request.form.get('role')
            if target_user_id in users and new_role in ['buyer', 'seller', 'admin']:
                users[target_user_id]['role'] = new_role
                save_json(USERS_FILE, users)
                flash(f'Роль изменена', 'success')
        
        elif action == 'block':
            if target_user_id in users:
                users[target_user_id]['blocked'] = True
                save_json(USERS_FILE, users)
                flash('Пользователь заблокирован', 'success')
        
        elif action == 'unblock':
            if target_user_id in users:
                users[target_user_id]['blocked'] = False
                save_json(USERS_FILE, users)
                flash('Пользователь разблокирован', 'success')
        
        return redirect(url_for('admin_roles'))
    
    # Role constants
    ROLE_NAMES = {
        'owner': '👑 Владелец',
        'system_admin': '🛡 Системный админ',
        'admin': '🔧 Администратор',
        'seller': '📋 Продавец',
        'buyer': '🛒 Покупатель',
        'guest': '👤 Гость'
    }
    
    users_list = []
    for uid, u in users.items():
        role = u.get('role', 'guest')
        users_list.append({
            'id': uid,
            'email': u.get('email', 'N/A'),
            'username': u.get('username', 'N/A'),
            'role': role,
            'role_badge': ROLE_NAMES.get(role, '👤 Гость'),
            'blocked': u.get('blocked', False),
            'created_at': u.get('created_at', 'N/A')
        })
    
    settings = load_json(SETTINGS_FILE)
    
    return render_template('admin_roles.html',
                         users=users_list,
                         role_names=ROLE_NAMES,
                         user=user,
                         settings=settings)


# Профиль
@app.route('/profile')
@login_required
def profile():
    user = get_current_user()
    settings = load_json(SETTINGS_FILE)
    return render_template('profile.html', user=user, settings=settings)

# Настройки профиля
@app.route('/profile/settings', methods=['GET', 'POST'])
@login_required
def profile_settings():
    users = load_json(USERS_FILE)
    user = users[session['user_id']]
    
    if request.method == 'POST':
        user['name'] = request.form.get('name', user['name'])
        user['username'] = request.form.get('username', user['username'])
        user['description'] = request.form.get('description', '')
        
        save_json(USERS_FILE, users)
        flash('Настройки сохранены', 'success')
        return redirect(url_for('profile'))
    
    settings = load_json(SETTINGS_FILE)
    return render_template('profile_settings.html', user=user, settings=settings)

# Мои заявки
@app.route('/profile/requests')
@login_required
def profile_requests():
    all_requests = load_json(REQUESTS_FILE)
    user_requests = {k: v for k, v in all_requests.items() 
                    if v.get('user_id') == session['user_id']}
    
    user = get_current_user()
    settings = load_json(SETTINGS_FILE)
    
    return render_template('profile_requests.html',
                         requests=sorted(user_requests.values(), 
                                       key=lambda x: x.get('created_at', ''),
                                       reverse=True),
                         user=user,
                         settings=settings)

# Визитка пользователя
@app.route('/<user_id>')
def user_card(user_id):
    users = load_json(USERS_FILE)
    
    if user_id not in users:
        flash('Пользователь не найден', 'warning')
        return redirect(url_for('index'))
    
    card_user = users[user_id]
    current_user = get_current_user()
    settings = load_json(SETTINGS_FILE)
    
    return render_template('user_card.html',
                         card_user=card_user,
                         user=current_user,
                         settings=settings)

# Панель продавца
@app.route('/seller')
@seller_required
def seller_dashboard():
    all_requests = load_json(REQUESTS_FILE)
    
    stats = {
        'new': sum(1 for r in all_requests.values() if r.get('status') == 'pending_payment'),
        'active': sum(1 for r in all_requests.values() if r.get('status') == 'in_progress'),
        'completed': sum(1 for r in all_requests.values() if r.get('status') == 'completed')
    }
    
    recent_requests = sorted(all_requests.values(),
                           key=lambda x: x.get('created_at', ''),
                           reverse=True)[:10]
    
    user = get_current_user()
    settings = load_json(SETTINGS_FILE)
    
    return render_template('seller_dashboard.html',
                         stats=stats,
                         recent_requests=recent_requests,
                         user=user,
                         settings=settings)

# Заявки продавца
@app.route('/seller/requests')
@seller_required
def seller_requests():
    all_requests = load_json(REQUESTS_FILE)
    
    status_filter = request.args.get('status', 'all')
    
    if status_filter != 'all':
        filtered = {k: v for k, v in all_requests.items() 
                   if v.get('status') == status_filter}
    else:
        filtered = all_requests
    
    requests_list = sorted(filtered.values(),
                          key=lambda x: x.get('created_at', ''),
                          reverse=True)
    
    user = get_current_user()
    settings = load_json(SETTINGS_FILE)
    
    return render_template('seller_requests.html',
                         requests=requests_list,
                         status_filter=status_filter,
                         user=user,
                         settings=settings)

# Обновить статус заявки
@app.route('/seller/request/<request_id>/status', methods=['POST'])
@seller_required
def update_request_status(request_id):
    all_requests = load_json(REQUESTS_FILE)
    
    if request_id in all_requests:
        new_status = request.form.get('status')
        old_status = all_requests[request_id]['status']
        all_requests[request_id]['status'] = new_status
        save_json(REQUESTS_FILE, all_requests)
        
        # Отправка уведомления пользователю в Telegram
        users = load_json(USERS_FILE)
        user_id = all_requests[request_id]['user_id']
        
        if user_id in users and users[user_id].get('telegram_id'):
            telegram_id = users[user_id]['telegram_id']
            service_name = all_requests[request_id]['service_name']
            
            status_messages = {
                'paid': f'✅ *Ваша заявка оплачена!*\n\nЗаявка: {service_name}\nРабота будет начата в ближайшее время.',
                'in_progress': f'🔨 *Работа над заявкой начата!*\n\nЗаявка: {service_name}\nМы приступили к выполнению.',
                'awaiting_response': f'💬 *Требуется ваш ответ*\n\nЗаявка: {service_name}\nПожалуйста, проверьте детали.',
                'completed': f'✔️ *Заявка завершена!*\n\nЗаявка: {service_name}\nСпасибо за работу с нами!'
            }
            
            if new_status in status_messages:
                send_telegram_notification(telegram_id, status_messages[new_status])
        
        flash('Статус обновлён', 'success')
    
    return redirect(url_for('seller_requests'))

# Управление услугами
@app.route('/seller/services', methods=['GET', 'POST'])
@seller_required
def seller_services():
    services = load_json(SERVICES_FILE)
    
    if request.method == 'POST':
        action = request.form.get('action')
        
        if action == 'add':
            new_id = str(max([int(k) for k in services.keys()]) + 1) if services else '1'
            services[new_id] = {
                'id': new_id,
                'category': request.form.get('category'),
                'name': request.form.get('name'),
                'description': request.form.get('description'),
                'price': int(request.form.get('price', 0)),
                'icon': request.form.get('icon', '📦'),
                'active': True
            }
            flash('Услуга добавлена', 'success')
        
        elif action == 'toggle':
            service_id = request.form.get('service_id')
            if service_id in services:
                services[service_id]['active'] = not services[service_id].get('active', True)
                flash('Статус услуги изменён', 'success')
        
        save_json(SERVICES_FILE, services)
        return redirect(url_for('seller_services'))
    
    user = get_current_user()
    settings = load_json(SETTINGS_FILE)
    
    return render_template('seller_services.html',
                         services=list(services.values()),
                         user=user,
                         settings=settings)

# Клиенты
@app.route('/seller/clients')
@seller_required
def seller_clients():
    users = load_json(USERS_FILE)
    all_requests = load_json(REQUESTS_FILE)
    
    clients = []
    for user_id, user_data in users.items():
        if not user_data.get('is_seller'):
            order_count = sum(1 for r in all_requests.values() 
                            if r.get('user_id') == user_id)
            clients.append({
                **user_data,
                'order_count': order_count
            })
    
    user = get_current_user()
    settings = load_json(SETTINGS_FILE)
    
    return render_template('seller_clients.html',
                         clients=clients,
                         user=user,
                         settings=settings)

# Настройки студии
@app.route('/seller/settings', methods=['GET', 'POST'])
@seller_required
def seller_settings():
    settings = load_json(SETTINGS_FILE)
    
    if request.method == 'POST':
        settings['logo'] = request.form.get('logo', settings['logo'])
        settings['telegram_bot'] = request.form.get('telegram_bot', '')
        settings['notifications'] = request.form.get('notifications') == 'on'
        
        save_json(SETTINGS_FILE, settings)
        flash('Настройки сохранены', 'success')
        return redirect(url_for('seller_settings'))
    
    user = get_current_user()
    
    return render_template('seller_settings.html',
                         settings=settings,
                         user=user)

if __name__ == '__main__':
    debug_mode = os.getenv('DEBUG', 'True').lower() == 'true'
    host = os.getenv('HOST', '0.0.0.0')
    port = int(os.getenv('PORT', '5000'))
    app.run(debug=debug_mode, host=host, port=port)
