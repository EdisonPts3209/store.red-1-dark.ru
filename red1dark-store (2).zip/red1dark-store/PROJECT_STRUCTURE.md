# 📁 Полная структура проекта Red1Dark Store

```
red1dark-store/
│
├── 📄 ДОКУМЕНТАЦИЯ
│   ├── README.md                          # Основная информация
│   ├── SETUP.md                          # Установка и настройка
│   ├── QUICKSTART.md                     # Быстрый старт
│   ├── ARCHITECTURE.md                   # Архитектура приложения
│   ├── FEATURES.md                       # Список функций
│   ├── PRICELIST.md                      # Прайс-лист
│   ├── DEPLOYMENT.md                     # Развёртывание
│   ├── DEPLOYMENT_FINAL.md               # Финальное развёртывание
│   ├── OAUTH_SETUP.md                    # Настройка OAuth
│   ├── OAUTH_INTEGRATION.md              # Интеграция OAuth
│   ├── OAUTH_OTP_BOTS_READY.md          # OAuth и OTP готовность
│   ├── YANDEX_OAUTH_SETUP.md             # Яндекс OAuth
│   ├── DB_INTEGRATION_GUIDE.md           # Интеграция БД
│   ├── ROLES.md                          # Роли пользователей
│   ├── DOCS_INDEX.md                     # Индекс документации
│   ├── CHANGELOG.md                      # История изменений
│   ├── ФИНАЛЬНАЯ_ИНСТРУКЦИЯ.md           # Финальная инструкция
│   ├── ШПАРГАЛКА.md                      # Справка
│   ├── ГОТОВО.txt                        # Статус проекта
│   └── 00_START_HERE.md                  # С чего начать
│
├── 🔧 КОНФИГУРАЦИЯ
│   ├── .env                              # Переменные окружения
│   ├── .env.example                      # Пример .env
│   ├── .gitignore                        # Git исключения
│   └── requirements.txt                  # Python зависимости
│
├── 🚀 ЗАПУСК И СКРИПТЫ
│   ├── app.py                            # Главное Flask приложение
│   ├── run.sh                            # Скрипт запуска (Linux/Mac)
│   ├── run.bat                           # Скрипт запуска (Windows)
│   ├── start.sh                          # Альтернативный старт (Linux/Mac)
│   ├── start.bat                         # Альтернативный старт (Windows)
│   ├── quick_start.sh                    # Быстрый старт (Linux/Mac)
│   └── quick_start.bat                   # Быстрый старт (Windows)
│
├── 🐍 ОСНОВНОЙ КОД
│   ├── auth.py                           # Аутентификация
│   ├── auth_routes.py                    # Маршруты аутентификации
│   ├── oauth_handlers.py                 # Обработчики OAuth
│   ├── models.py                         # ORM модели
│   ├── db_utils.py                       # Утилиты базы данных
│   ├── init_db.py                        # Инициализация БД
│   ├── migrate_data.py                   # Миграция данных
│   └── verify_db.py                      # Проверка БД
│
├── 📊 ДАННЫЕ (JSON файлы)
│   ├── data/
│   │   ├── users.json                    # Пользователи
│   │   ├── services.json                 # Услуги/товары
│   │   ├── requests.json                 # Запросы
│   │   ├── settings.json                 # Параметры
│   │   └── user_roles.json               # Роли пользователей
│   │
│   └── instance/                         # Папка экземпляра приложения
│       └── (БД файлы)
│
├── 🎨 СТАТИЧЕСКИЕ ФАЙЛЫ
│   ├── static/
│   │   ├── css/
│   │   │   └── style.css                 # Основной CSS
│   │   ├── js/
│   │   │   └── main.js                   # Основной JavaScript
│   │   └── (изображения)
│   │
│   └── 📸 Логотипы в корне
│       ├── logo 1024x1024.png
│       └── logo 915x819.png
│
├── 🌐 HTML ШАБЛОНЫ
│   └── templates/
│       ├── base.html                     # Базовый шаблон
│       ├── index.html                    # Главная страница
│       ├── services.html                 # Услуги
│       ├── cart.html                     # Корзина
│       ├── request.html                  # Запрос услуги
│       ├── login.html                    # Вход
│       ├── register.html                 # Регистрация
│       ├── profile.html                  # Профиль пользователя
│       ├── profile_requests.html         # Мои запросы
│       ├── profile_settings.html         # Настройки профиля
│       ├── user_card.html                # Карточка пользователя
│       ├── admin_roles.html              # Управление ролями
│       ├── seller_dashboard.html         # Панель продавца
│       ├── seller_services.html          # Услуги продавца
│       ├── seller_requests.html          # Запросы продавца
│       ├── seller_clients.html           # Клиенты продавца
│       └── seller_settings.html          # Настройки продавца
│
├── 🤖 TELEGRAM БОТ
│   └── telegram_bot/
│       ├── bot.py                        # Основной бот
│       ├── config.py.example             # Пример конфига
│       ├── telegram_login_widget.py      # Виджет Telegram логина
│       ├── requirements.txt              # Зависимости бота
│       ├── README.md                     # Документация бота
│       ├── QUICKSTART.md                 # Быстрый старт бота
│       └── COMMANDS.md                   # Команды бота
│
├── 🛠️ ИНСТРУМЕНТЫ
│   └── tools/
│       └── check_headers.py              # Проверка заголовков
│
└── 📦 ВИРТУАЛЬНОЕ ОКРУЖЕНИЕ
    └── .venv/                            # Python виртуальное окружение
        └── (пакеты Python)
```

---

## 📋 Краткое описание основных папок

### `/data` - JSON база данных
- **users.json** - Профили пользователей
- **services.json** - Каталог услуг/товаров
- **requests.json** - Запросы на услуги
- **settings.json** - Глобальные параметры
- **user_roles.json** - Роли и права пользователей

### `/static` - Фронтенд ресурсы
- **css/** - Стили (style.css)
- **js/** - Скрипты (main.js)
- Логотипы и изображения

### `/templates` - HTML шаблоны (13+ файлов)
- **base.html** - Базовый layout
- **Страницы авторизации** - login.html, register.html
- **Пользовательские** - profile.html, services.html, cart.html
- **Панель продавца** - seller_dashboard.html, seller_services.html
- **Администрирование** - admin_roles.html

### `/telegram_bot` - Telegram интеграция
- **bot.py** - Основной бот для Telegram
- **telegram_login_widget.py** - Виджет входа
- **config.py.example** - Пример конфигурации

### `/tools` - Вспомогательные скрипты
- **check_headers.py** - Проверка HTTP заголовков

---

## 🔑 Ключевые файлы приложения

| Файл | Назначение |
|------|-----------|
| `app.py` | Главное Flask приложение |
| `models.py` | ORM модели БД |
| `auth.py` | Логика аутентификации |
| `auth_routes.py` | Маршруты авторизации |
| `oauth_handlers.py` | Обработчики OAuth (Яндекс, Telegram) |
| `db_utils.py` | Утилиты работы с БД |
| `.env` | Секреты и конфиг |

---

## 📦 Структура виртуального окружения

`.venv/` содержит все установленные Python пакеты из `requirements.txt`

---

## 🚀 Стартовые скрипты

- **Linux/Mac**: `./run.sh` или `./start.sh`
- **Windows**: `run.bat` или `start.bat`
- **Быстрый старт**: `quick_start.sh` или `quick_start.bat`

---

## 📚 Документация по темам

| Документ | Содержание |
|----------|-----------|
| SETUP.md | Полная установка |
| QUICKSTART.md | 5 минут до работы |
| ARCHITECTURE.md | Архитектура системы |
| OAUTH_SETUP.md | OAuth для Яндекса |
| DB_INTEGRATION_GUIDE.md | Работа с БД |
| DEPLOYMENT.md | Развёртывание на сервер |
| ROLES.md | Система ролей |

---

✅ **Проект готов к использованию!**
