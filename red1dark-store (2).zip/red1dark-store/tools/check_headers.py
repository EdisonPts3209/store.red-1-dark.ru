import os
import sys
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from app import app

with app.test_client() as client:
    resp = client.get('/')
    print('Status:', resp.status_code)
    print('Content-Type header:', resp.headers.get('Content-Type'))
    # print all headers for inspection
    for k, v in resp.headers.items():
        print(f"{k}: {v}")
