# Маршруты авторизации для основного app.py
# Вставить после импортов в app.py

# ============ АВТОРИЗАЦИЯ И РЕГИСТРАЦИЯ ============

@app.route('/register', methods=['GET', 'POST'])
def register():
    """Регистрация нового пользователя"""
    from auth import create_user, generate_otp, send_otp_email, OTP_STORAGE
    from datetime import timedelta, datetime
    
    if request.method == 'POST':
        email = request.form.get('email', '').lower()
        username = request.form.get('username', '')
        password = request.form.get('password', '')
        password_confirm = request.form.get('password_confirm', '')
        
        # Валидация
        if not email or not username or not password:
            flash('Все поля обязательны', 'danger')
            return redirect(url_for('register'))
        
        if password != password_confirm:
            flash('Пароли не совпадают', 'danger')
            return redirect(url_for('register'))
        
        if len(password) < 6:
            flash('Пароль должен быть минимум 6 символов', 'danger')
            return redirect(url_for('register'))
        
        # Создание пользователя
        user_id, message = create_user(email, username, password)
        
        if not user_id:
            flash(message, 'danger')
            return redirect(url_for('register'))
        
        # Генерация и отправка OTP
        otp = generate_otp()
        OTP_STORAGE[email] = {
            'code': otp,
            'expires_at': datetime.now() + timedelta(minutes=10),
            'user_id': user_id
        }
        send_otp_email(email, otp)
        
        session['pending_email'] = email
        flash(f'Пользователь создан! На {email} отправлен код подтверждения', 'info')
        return redirect(url_for('verify_otp'))
    
    settings = load_json(SETTINGS_FILE)
    return render_template('register.html', settings=settings)


@app.route('/login', methods=['GET', 'POST'])
def login():
    """Вход по email и паролю"""
    from auth import verify_password, generate_otp, send_otp_email, OTP_STORAGE
    from datetime import timedelta, datetime
    
    if request.method == 'POST':
        email = request.form.get('email', '').lower()
        password = request.form.get('password', '')
        
        users = load_json(USERS_FILE)
        user = None
        user_id = None
        
        # Поиск пользователя по email
        for uid, u in users.items():
            if u.get('email') == email:
                user = u
                user_id = uid
                break
        
        if not user:
            flash('Пользователь не найден', 'danger')
            return redirect(url_for('login'))
        
        if user.get('blocked'):
            flash('Ваш аккаунт заблокирован', 'danger')
            return redirect(url_for('login'))
        
        if not verify_password(user.get('password_hash', ''), password):
            flash('Неверный пароль', 'danger')
            return redirect(url_for('login'))
        
        # Генерация OTP для подтверждения
        otp = generate_otp()
        OTP_STORAGE[email] = {
            'code': otp,
            'expires_at': datetime.now() + timedelta(minutes=10),
            'user_id': user_id
        }
        send_otp_email(email, otp)
        
        session['pending_email'] = email
        session['pending_user_id'] = user_id
        flash(f'На {email} отправлен код подтверждения', 'info')
        return redirect(url_for('verify_otp'))
    
    settings = load_json(SETTINGS_FILE)
    return render_template('login.html', settings=settings)


@app.route('/verify-otp', methods=['GET', 'POST'])
def verify_otp():
    """Подтверждение OTP кода"""
    from auth import verify_otp as check_otp
    
    if request.method == 'POST':
        email = session.get('pending_email')
        otp_code = request.form.get('otp_code', '')
        
        if not email:
            flash('Сессия истекла. Попробуйте снова', 'danger')
            return redirect(url_for('login'))
        
        success, message = check_otp(email, otp_code)
        
        if success:
            user_id = session.get('pending_user_id')
            if not user_id:
                # Поиск пользователя по email для регистрации
                users = load_json(USERS_FILE)
                for uid, u in users.items():
                    if u.get('email') == email:
                        user_id = uid
                        break
            
            if user_id:
                # Успешный вход
                session['user_id'] = user_id
                session.pop('pending_email', None)
                session.pop('pending_user_id', None)
                
                users = load_json(USERS_FILE)
                user = users.get(user_id, {})
                
                flash(f"Добро пожаловать, {user.get('username', 'Гость')}!", 'success')
                return redirect(url_for('profile'))
        
        flash(message, 'danger')
        return redirect(url_for('verify_otp'))
    
    settings = load_json(SETTINGS_FILE)
    return render_template('verify_otp.html', settings=settings)


@app.route('/auth/vk/callback')
def vk_oauth_callback():
    """Callback для VK OAuth"""
    from auth import create_user, ROLES
    
    code = request.args.get('code')
    error = request.args.get('error')
    
    if error:
        flash(f'VK OAuth ошибка: {error}', 'danger')
        return redirect(url_for('login'))
    
    # Обмен кода на токен (упрощённо)
    vk_client_id = os.getenv('VK_CLIENT_ID')
    vk_client_secret = os.getenv('VK_CLIENT_SECRET')
    redirect_uri = os.getenv('VK_REDIRECT_URI')
    
    # В реальном коде здесь нужно получить токен и информацию пользователя
    # Для демо просто создаём/логиним пользователя
    
    flash('VK авторизация: требуется настройка', 'warning')
    return redirect(url_for('login'))


@app.route('/auth/telegram')
def telegram_oauth():
    """Инициирует Telegram OAuth"""
    telegram_app_id = os.getenv('TELEGRAM_CLIENT_ID')
    
    if not telegram_app_id:
        flash('Telegram OAuth не настроен', 'danger')
        return redirect(url_for('login'))
    
    flash('Telegram авторизация: требуется настройка', 'warning')
    return redirect(url_for('login'))


@app.route('/logout')
def logout():
    """Выход из системы"""
    session.clear()
    flash('Вы вышли из системы', 'info')
    return redirect(url_for('index'))


# ============ АДМИН-ПАНЕЛЬ: УПРАВЛЕНИЕ РОЛЯМИ ============

@app.route('/admin/roles', methods=['GET', 'POST'])
def admin_roles():
    """Управление ролями пользователей"""
    from auth import require_role, assign_role, get_role_badge, ROLES
    
    user = get_current_user()
    if not user:
        return redirect(url_for('login'))
    
    user_role = user.get('role', 'guest')
    user_id = session.get('user_id')
    
    # Только owner, system_admin и admin могут управлять ролями
    if user_role not in ['owner', 'system_admin', 'admin']:
        flash('Недостаточно прав', 'danger')
        return redirect(url_for('index'))
    
    users = load_json(USERS_FILE)
    
    if request.method == 'POST':
        action = request.form.get('action')
        target_user_id = request.form.get('user_id')
        
        if action == 'assign_role':
            new_role = request.form.get('role')
            success, message = assign_role(target_user_id, new_role, user_id)
            flash(message, 'success' if success else 'danger')
        
        elif action == 'block':
            if target_user_id in users:
                users[target_user_id]['blocked'] = True
                save_json(USERS_FILE, users)
                flash('Пользователь заблокирован', 'success')
        
        elif action == 'unblock':
            if target_user_id in users:
                users[target_user_id]['blocked'] = False
                save_json(USERS_FILE, users)
                flash('Пользователь разблокирован', 'success')
        
        return redirect(url_for('admin_roles'))
    
    # Форматирование пользователей с бейджами
    users_list = []
    for uid, u in users.items():
        users_list.append({
            'id': uid,
            'email': u.get('email', 'N/A'),
            'username': u.get('username', 'N/A'),
            'role': u.get('role', 'guest'),
            'role_badge': get_role_badge(u.get('role', 'guest')),
            'blocked': u.get('blocked', False),
            'created_at': u.get('created_at', 'N/A')
        })
    
    settings = load_json(SETTINGS_FILE)
    
    return render_template('admin_roles.html',
                         users=users_list,
                         roles=ROLES,
                         user=user,
                         settings=settings)
