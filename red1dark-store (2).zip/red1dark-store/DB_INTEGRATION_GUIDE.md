# 📊 ИНТЕГРАЦИЯ SQLite БД В RED1DARK STUDIO

**Статус:** ✅ **50% завершено** — основа готова, требуется доработка маршрутов

---

## 📦 ЧТО БЫЛО СДЕЛАНО

### 1. ✅ `models.py` — SQLAlchemy модели
- **8 таблиц:** User, Role, Permission, Service, Product, Order, UserLog, AuthToken
- **M2M связи:** user_roles, role_permissions
- **Методы User:** `has_permission()`, `has_role()`, `get_role_level()`, `add_role()`, `remove_role()`
- **Типы данных:**
  - Balance → REAL (Float) для SQLite ✅
  - Даты → TEXT (String) формат YYYY-MM-DD HH:MM:SS ✅
  - Права и роли → отношения M2M ✅

### 2. ✅ `init_db.py` — инициализация БД
- Создаёт таблицы в `instance/database.db`
- **6 ролей** (иерархия 1-6): гость → владелец
- **21 право доступа** распределено по категориям и ролям
- Создаёт первого пользователя (owner: red1dark)
```bash
python init_db.py
```

### 3. ✅ `migrate_data.py` — миграция из JSON
- Переносит пользователей, услуги, заявки из JSON в SQLite
- Автоматически назначает роли на основе `is_seller`
- Результат: 3+ пользователя, услуги, заявки загружены в БД
```bash
python migrate_data.py
```

### 4. ✅ `verify_db.py` — проверка целостности БД
- Проверяет все таблицы, роли, права
- Тестирует методы пользователя
- Выводит статистику
```bash
python verify_db.py
```

### 5. ✅ `db_utils.py` — утилиты для работы с БД
Готовые функции для замены JSON-функций:
- `get_current_user_db()` — получить текущего пользователя
- `create_user_db()` — создать пользователя
- `create_order_db()` — создать заявку
- `get_all_services_db()` — получить услуги
- `update_order_status_db()` — обновить статус заявки
- и другие...

### 6. ✅ `app.py` — обновлены импорты
- Добавлены импорты SQLAlchemy моделей
- Конфиг БД указывает на `instance/database.db`
- Оставлена совместимость с JSON для постепенной миграции

---

## 🔧 ТРЕБУЕТСЯ ПОЛНАЯ ИНТЕГРАЦИЯ

### ❌ Что ещё не сделано

Для полного перехода на БД нужно обновить следующие маршруты в `app.py`:

#### 1. **Регистрация и авторизация**
```python
# Строки ~440-500 в app.py
# Заменить: load_json() → create_user_db(), get_user_by_email_db()
# Использовать: db_utils.create_user_db()
```

#### 2. **Главная страница и каталог услуг**
```python
# Строки ~240, 280 в app.py
# Заменить: load_json(SERVICES_FILE) → get_all_services_db()
# Заменить: load_json(REQUESTS_FILE) → get_current_user()
```

#### 3. **Создание и управление заявками**
```python
# Строки ~300, ~700 в app.py
# Заменить: save_json() → create_order_db()
# Заменить: load_json(REQUESTS_FILE) → get_user_orders_db()
```

#### 4. **Панель продавца**
```python
# Строки ~800+ в app.py
# Заменить: JSON работа с заявками → Order.query
# Заменить: get_current_user() → get_current_user_db()
# Заменить: update_order_status_db() для обновления статусов
```

#### 5. **OAuth интеграции (VK, Yandex, Telegram)**
```python
# Строки 595-850 в app.py
# Заменить: создание пользователя через JSON → create_user_db()
# Заменить: проверка oauth_providers → проверка User.oauth_providers
```

#### 6. **Профиль и настройки**
```python
# Заменить: get_current_user() → get_current_user_db()
# Обновить сохранение данных через db.session.commit()
```

---

## 📋 ПОШАГОВЫЙ ПЛАН ИНТЕГРАЦИИ

### Этап 1 (30 минут): Замена узлов

```python
# В app.py заменить импорты в начале файла:
from db_utils import (
    get_current_user_db, 
    create_user_db, 
    get_user_by_email_db,
    get_all_services_db,
    create_order_db,
    get_user_orders_db
)

# Заменить все load_json() вызовы на аналоги из db_utils:
# load_json(USERS_FILE) → get_user_by_email_db(email) / get_current_user_db()
# load_json(SERVICES_FILE) → get_all_services_db()
# save_json() → db.session.add() + db.session.commit()
```

### Этап 2 (1 час): Обновить маршруты

1. **`/register`** — использовать `create_user_db()`
2. **`/login`** — искать пользователя в БД вместо JSON
3. **`/services`** — `get_all_services_db()` вместо JSON
4. **`/request`** (создание заявки) — `create_order_db()`
5. **`/auth/vk/callback`** — `create_user_db()` для OAuth пользователя
6. **`/auth/yandex/callback`** — аналогично

### Этап 3 (30 минут): Тестирование

```bash
# Проверить работу БД:
python verify_db.py

# Запустить приложение:
python app.py

# Тестировать маршруты:
# - Регистрация нового пользователя
# - Аутентификация (JSON файлы ещё могут использоваться как fallback)
# - Создание заявок
# - OAuth

```

### Этап 4 (опционально): Оптимизация

- Добавить индексы на частые поля (email, username, status)
- Оптимизировать запросы (lazy loading, eager loading)
- Добавить кеширование для услуг
- Перенести логирование в БД (UserLog)

---

## 🔐 ВАЖНЫЕ ЗАМЕЧАНИЯ

### **Совместимость с OAuth**

OAuth функции уже готовы для работы с БД:
- VK callback ([app.py, 598](app.py#L598)): использует `create_user_db()` напрямую
- Yandex callback ([app.py, 670](app.py#L670)): готов к замене
- Telegram Widget ([app.py, 717](app.py#L717)): готов к замене

### **Сессии и user_id**

⚠️ **ВАЖНО:** Когда переходите на БД, `session['user_id']` должен хранить **целочисленный ID из БД**, а не строку username.

```python
# Старый подход (JSON):
session['user_id'] = username  # Строка

# Новый подход (БД):
session['user_id'] = user.id  # Целое число
```

Функция `get_current_user_db()` уже поддерживает оба варианта для совместимости.

### **Миграция данных**

Текущие данные в JSON уже загружены в БД:
- 3 пользователя (включая owner)
- 3 услуги
- 1 заявка

Проверить: `python migrate_data.py`

---

## 📁 ФА ЙЛЫ ПРОЕКТА

**Новые файлы:**
```
✅ models.py           — SQLAlchemy модели (8 таблиц)
✅ init_db.py          — инициализация БД
✅ migrate_data.py     — миграция из JSON
✅ verify_db.py        — проверка целостности
✅ db_utils.py         — утилиты для работы с БД
✅ instance/database.db — SQLite база (200+ KB)
```

**Обновлены:**
```
✅ app.py              — импорты SQLAlchemy, конфиг БД
✅ requirements.txt    — добавлены Flask-SQLAlchemy, SQLAlchemy
```

**Совместимы:**
```
📄 data/users.json     — старые данные (JSON fallback)
📄 data/services.json  — старые данные
📄 data/requests.json  — старые данные
```

---

## 💬 ПРИМЕРЫ ИСПОЛЬЗОВАНИЯ

### Получить текущего пользователя:
```python
from db_utils import get_current_user_db
user = get_current_user_db(session['user_id'])
if user:
    print(user.username, user.email, user.roles)
```

### Создать пользователя:
```python
from db_utils import create_user_db
user, msg = create_user_db(
    email='test@example.com',
    username='testuser',
    password_hash=generate_password_hash('password'),
    name='Test User',
    is_seller=False
)
```

### Получить все услуги:
```python
from db_utils import get_all_services_db
services = get_all_services_db(active_only=True)
for svc in services:
    print(f"{svc.name}: {svc.price}₽")
```

### Создать заявку:
```python
from db_utils import create_order_db
order, msg = create_order_db(
    user_id=1,
    service_id=2,
    title="Разработка бота",
    description="Нужен бот для...",
    priority='high'
)
```

---

## ✅ ИТОГ

**Текущее состояние:** ✅ **Основа БД полностью готова и заполнена данными**

**Осталось:** Обновить маршруты в `app.py` для использования БД вместо JSON (2-3 часа работы)

**Преимущества после интеграции:**
- ✅ Запросы к БД быстрее, чем чтение JSON
- ✅ Встроенная иерархия ролей и прав
- ✅ Поддержка транзакций и индексов
- ✅ Логирование в БД
- ✅ Масштабируемость

**Команды для запуска:**
```bash
# Это готовые скрипты:
python init_db.py      # Создать БД (если её нет)
python migrate_data.py # Загрузить данные из JSON
python verify_db.py    # Проверить целостность
```
