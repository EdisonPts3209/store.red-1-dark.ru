"""
Модуль для работы с Telegram Login Widget
Интеграция OAuth авторизации для веб-приложения
"""

import hashlib
import hmac
import time
from datetime import datetime

class TelegramLoginWidget:
    """Класс для работы с Telegram Login Widget"""
    
    def __init__(self, bot_token):
        """
        Инициализация виджета
        
        Args:
            bot_token: Токен Telegram бота
        """
        self.bot_token = bot_token
    
    def verify_auth_data(self, auth_data):
        """
        Проверка подлинности данных от Telegram Login Widget
        
        Args:
            auth_data: dict с данными от виджета
            
        Returns:
            bool: True если данные подлинные
        """
        if not auth_data or 'hash' not in auth_data:
            return False
        
        # Получаем hash из данных
        received_hash = auth_data.pop('hash')
        
        # Создаем строку для проверки
        data_check_arr = []
        for key in sorted(auth_data.keys()):
            value = auth_data[key]
            if value:
                data_check_arr.append(f"{key}={value}")
        
        data_check_string = '\n'.join(data_check_arr)
        
        # Вычисляем hash
        secret_key = hashlib.sha256(self.bot_token.encode()).digest()
        calculated_hash = hmac.new(
            secret_key,
            data_check_string.encode(),
            hashlib.sha256
        ).hexdigest()
        
        # Возвращаем hash обратно
        auth_data['hash'] = received_hash
        
        return calculated_hash == received_hash
    
    def check_auth_date(self, auth_data, max_age=86400):
        """
        Проверка времени авторизации
        
        Args:
            auth_data: dict с данными
            max_age: максимальный возраст данных в секундах (по умолчанию 24 часа)
            
        Returns:
            bool: True если данные свежие
        """
        if 'auth_date' not in auth_data:
            return False
        
        try:
            auth_date = int(auth_data['auth_date'])
            current_time = int(time.time())
            
            return (current_time - auth_date) <= max_age
        except:
            return False
    
    def extract_user_data(self, auth_data):
        """
        Извлечение данных пользователя
        
        Args:
            auth_data: dict с данными от виджета
            
        Returns:
            dict: Данные пользователя для создания в системе
        """
        if not self.verify_auth_data(auth_data.copy()):
            return None
        
        if not self.check_auth_date(auth_data):
            return None
        
        user_data = {
            'telegram_id': int(auth_data.get('id', 0)),
            'first_name': auth_data.get('first_name', ''),
            'last_name': auth_data.get('last_name', ''),
            'username': auth_data.get('username', ''),
            'photo_url': auth_data.get('photo_url', ''),
            'auth_date': auth_data.get('auth_date', ''),
        }
        
        return user_data
    
    def create_user_from_widget(self, auth_data, users_file_path, roles_file_path):
        """
        Создать пользователя из данных виджета
        
        Args:
            auth_data: dict с данными от виджета
            users_file_path: путь к users.json
            roles_file_path: путь к user_roles.json
            
        Returns:
            dict: Созданный пользователь или None
        """
        import json
        import os
        
        # Проверяем данные
        user_data = self.extract_user_data(auth_data)
        if not user_data:
            return None
        
        # Загружаем существующих пользователей
        try:
            with open(users_file_path, 'r', encoding='utf-8') as f:
                users = json.load(f)
        except:
            users = {}
        
        # Загружаем роли
        try:
            with open(roles_file_path, 'r', encoding='utf-8') as f:
                roles = json.load(f)
        except:
            roles = {}
        
        # ID пользователя
        user_id = f"tg_{user_data['telegram_id']}"
        
        # Проверяем, существует ли пользователь
        if user_id in users:
            return users[user_id]
        
        # Определяем роль (по умолчанию client)
        role = roles.get(str(user_data['telegram_id']), 'client')
        
        # Создаем пользователя
        new_user = {
            'id': user_id,
            'telegram_id': user_data['telegram_id'],
            'name': f"{user_data['first_name']} {user_data['last_name']}".strip(),
            'username': user_data['username'] or f"tg{user_data['telegram_id']}",
            'avatar': user_data['photo_url'],
            'email': '',
            'registered_at': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            'role': role,
            'is_seller': role in ['seller', 'admin', 'owner'],
            'description': '',
            'auth_via': 'telegram_widget'
        }
        
        # Сохраняем
        users[user_id] = new_user
        
        os.makedirs(os.path.dirname(users_file_path), exist_ok=True)
        with open(users_file_path, 'w', encoding='utf-8') as f:
            json.dump(users, f, ensure_ascii=False, indent=2)
        
        return new_user


def generate_widget_html(bot_username, redirect_url, size='large'):
    """
    Генерация HTML кода для Telegram Login Widget
    
    Args:
        bot_username: Username бота (без @)
        redirect_url: URL для перенаправления после авторизации
        size: Размер виджета (small, medium, large)
        
    Returns:
        str: HTML код виджета
    """
    html = f'''
<script async src="https://telegram.org/js/telegram-widget.js?22" 
        data-telegram-login="{bot_username}" 
        data-size="{size}" 
        data-auth-url="{redirect_url}" 
        data-request-access="write">
</script>
'''
    return html


def get_widget_instructions(bot_username, domain):
    """
    Инструкции по настройке виджета
    
    Args:
        bot_username: Username бота
        domain: Домен сайта
        
    Returns:
        str: Текст инструкции
    """
    instructions = f"""
📝 Инструкция по настройке Telegram Login Widget:

1. Настройте домен в @BotFather:
   - Отправьте /setdomain
   - Выберите бота @{bot_username}
   - Укажите домен: {domain} (БЕЗ https://)

2. Добавьте виджет на сайт:
   - Используйте готовый HTML код
   - Укажите callback URL
   - Проверьте, что бот работает

3. Настройте обработчик на сервере:
   - Создайте маршрут для callback
   - Проверяйте подпись данных
   - Создавайте пользователя в системе

4. Тестирование:
   - Откройте сайт
   - Нажмите на виджет
   - Подтвердите в Telegram
   - Проверьте авторизацию

⚠️ Важно:
- Домен должен быть БЕЗ https://
- Callback URL должен быть с https://
- Всегда проверяйте подпись данных
"""
    return instructions


# Пример использования в Flask
FLASK_EXAMPLE = '''
from flask import Flask, request, session, redirect, url_for
from telegram_login_widget import TelegramLoginWidget

app = Flask(__name__)
BOT_TOKEN = "7722261852:AAFaPXyIChqI49QWKfmxEDv9oSXCSyBWiB0н"
widget = TelegramLoginWidget(BOT_TOKEN)

@app.route('/auth/telegram/callback')
def telegram_callback():
    # Получаем данные из query параметров
    auth_data = {
        'id': request.args.get('id'),
        'first_name': request.args.get('first_name'),
        'last_name': request.args.get('last_name', ''),
        'username': request.args.get('username', ''),
        'photo_url': request.args.get('photo_url', ''),
        'auth_date': request.args.get('auth_date'),
        'hash': request.args.get('hash')
    }
    
    # Проверяем подлинность
    if not widget.verify_auth_data(auth_data.copy()):
        return "Ошибка проверки подлинности", 403
    
    # Создаем пользователя
    user = widget.create_user_from_widget(
        auth_data,
        'data/users.json',
        'data/user_roles.json'
    )
    
    if user:
        session['user_id'] = user['id']
        return redirect(url_for('index'))
    
    return "Ошибка авторизации", 400
'''

if __name__ == '__main__':
    # Пример использования
    BOT_TOKEN = "123456789:ABCdefGHIjklMNOpqrsTUVwxyz"
    BOT_USERNAME = "red1dark_bot"
    DOMAIN = "store.red-1-dark.ru"
    
    widget = TelegramLoginWidget(BOT_TOKEN)
    
    # Генерация HTML
    html = generate_widget_html(
        bot_username=storered1darkru_bot,
        redirect_url=f"https://{DOMAIN}/auth/telegram/callback",
        size="large"
    )
    
    print("HTML код виджета:")
    print(html)
    
    print("\nИнструкции:")
    print(get_widget_instructions(BOT_USERNAME, DOMAIN))
