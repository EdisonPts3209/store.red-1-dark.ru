"""
Скрипт миграции данных из JSON в SQLite.
Переносит пользователей, услуги и заявки из JSON в базу данных.
"""

import json
import os
from datetime import datetime
from werkzeug.security import generate_password_hash

from app import app, db
from models import User, Role, Service, Order


def load_json(filepath):
    """Загружает данные из JSON файла"""
    try:
        if os.path.exists(filepath):
            with open(filepath, 'r', encoding='utf-8') as f:
                return json.load(f)
    except Exception as e:
        print(f'❌ Ошибка чтения {filepath}: {e}')
    return {}


def migrate_users():
    """Мигрирует пользователей из JSON в БД"""
    print('👥 Миграция пользователей...')
    
    users_json = load_json('data/users.json')
    if not users_json:
        print('   ⚠️ Нет пользователей для миграции')
        return 0
    
    migrated = 0
    with app.app_context():
        # Получаем роли (buyer по умолчанию)
        buyer_role = Role.query.filter_by(name='buyer').first()
        seller_role = Role.query.filter_by(name='seller').first()
        
        for user_id, user_data in users_json.items():
            # Проверяем, не существует ли уже
            existing = User.query.filter_by(email=user_data.get('email')).first()
            if existing:
                print(f'   ⚠️ Пользователь {user_data.get("username")} уже существует, пропускаем')
                continue
            
            # Создаём пользователя
            new_user = User(
                email=user_data.get('email', f'user_{user_id}@example.com'),
                username=user_data.get('username', f'user_{user_id}'),
                name=user_data.get('name', user_data.get('username', '')),
                password_hash=user_data.get('password_hash', ''),
                avatar=user_data.get('avatar', ''),
                description=user_data.get('description', ''),
                oauth_providers=json.dumps(user_data.get('oauth_providers', {})),
                is_active=user_data.get('is_active', False),
                email_verified=user_data.get('email_verified', False),
                blocked=user_data.get('blocked', False),
                is_seller=user_data.get('is_seller', False),
                balance=0.0,
                created_at=user_data.get('created_at', datetime.now().strftime('%Y-%m-%d %H:%M:%S')),
                updated_at=user_data.get('updated_at', datetime.now().strftime('%Y-%m-%d %H:%M:%S')),
                last_login=user_data.get('last_login')
            )
            
            # Назначаем роль
            if user_data.get('is_seller') and seller_role:
                new_user.roles.append(seller_role)
            elif buyer_role:
                new_user.roles.append(buyer_role)
            
            db.session.add(new_user)
            print(f'   ✓ {new_user.username} ({new_user.email})')
            migrated += 1
        
        db.session.commit()
    
    print(f'✅ Мигрировано пользователей: {migrated}')
    return migrated


def migrate_services():
    """Мигрирует услуги из JSON в БД"""
    print('🛍️ Миграция услуг...')
    
    services_json = load_json('data/services.json')
    if not services_json:
        print('   ⚠️ Нет услуг для миграции')
        return 0
    
    migrated = 0
    with app.app_context():
        for service_id, service_data in services_json.items():
            # Проверяем, не существует ли уже
            existing = Service.query.filter_by(name=service_data.get('name')).first()
            if existing:
                print(f'   ⚠️ Услуга {service_data.get("name")} уже существует, пропускаем')
                continue
            
            # Создаём услугу
            new_service = Service(
                name=service_data.get('name', ''),
                description=service_data.get('description', ''),
                category=service_data.get('category', 'other'),
                price=float(service_data.get('price', 0)),
                duration=service_data.get('duration', ''),
                icon=service_data.get('icon', ''),
                is_active=service_data.get('active', True),
                created_at=datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                updated_at=datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            )
            
            db.session.add(new_service)
            print(f'   ✓ {new_service.name} ({new_service.price}₽)')
            migrated += 1
        
        db.session.commit()
    
    print(f'✅ Мигрировано услуг: {migrated}')
    return migrated


def migrate_orders():
    """Мигрирует заявки из JSON в БД"""
    print('📦 Миграция заявок...')
    
    requests_json = load_json('data/requests.json')
    if not requests_json:
        print('   ⚠️ Нет заявок для миграции')
        return 0
    
    migrated = 0
    with app.app_context():
        for request_id, request_data in requests_json.items():
            user_id = request_data.get('user_id')
            service_id = request_data.get('service_id')
            
            # Ищем пользователя и услугу по имени (так как в JSON используются строк. ID)
            user = User.query.filter_by(username=request_data.get('username')).first()
            
            # Ищем услугу по названию
            service = Service.query.filter_by(name=request_data.get('service_name')).first()
            
            if not user:
                print(f'   ⚠️ Пользователь {request_data.get("username")} не найден, пропускаем заявку')
                continue
            
            if not service:
                print(f'   ⚠️ Услуга {request_data.get("service_name")} не найдена, пропускаем заявку')
                continue
            
            # Создаём заявку
            new_order = Order(
                user_id=user.id,
                service_id=service.id,
                title=request_data.get('service_name', ''),
                description=request_data.get('description', ''),
                status=request_data.get('status', 'pending_payment'),
                priority=request_data.get('priority', 'normal'),
                amount=float(service.price),
                source=request_data.get('source', 'web'),
                created_at=request_data.get('created_at', datetime.now().strftime('%Y-%m-%d %H:%M:%S')),
                updated_at=request_data.get('updated_at', datetime.now().strftime('%Y-%m-%d %H:%M:%S')),
                completed_at=request_data.get('completed_at')
            )
            
            db.session.add(new_order)
            print(f'   ✓ Заявка {new_order.id} ({user.username} -> {service.name})')
            migrated += 1
        
        db.session.commit()
    
    print(f'✅ Мигрировано заявок: {migrated}')
    return migrated


def migrate_data():
    """Полная миграция всех данных"""
    print('\n' + '='*70)
    print('📤 МИГРАЦИЯ ДАННЫХ ИЗ JSON В SQLITE')
    print('='*70 + '\n')
    
    try:
        users_count = migrate_users()
        services_count = migrate_services()
        orders_count = migrate_orders()
        
        print('\n' + '='*70)
        print('✅ МИГРАЦИЯ ЗАВЕРШЕНА')
        print(f'📊 Итого: {users_count} пользователей, {services_count} услуг, {orders_count} заявок')
        print('='*70 + '\n')
        
    except Exception as e:
        print(f'\n❌ ОШИБКА МИГРАЦИИ: {e}')
        import traceback
        traceback.print_exc()


if __name__ == '__main__':
    migrate_data()
