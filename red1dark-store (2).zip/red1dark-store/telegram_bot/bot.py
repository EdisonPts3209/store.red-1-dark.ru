"""
Telegram Bot для Red1dark Studio
Версия 2.0 с ролевой системой

Роли:
- Покупатель (client) - обычные пользователи
- Продавец (seller) - может управлять заявками
- Модератор (moderator) - может помогать клиентам
- Старший модератор (senior_moderator) - расширенные права
- Администратор (admin) - полный доступ
- Владелец (owner) - суперадмин
"""

import telebot
from telebot import types
import json
import os
from datetime import datetime
import hashlib
import hmac
from functools import wraps

# Конфигурация
BOT_TOKEN = "7722261852:AAFaPXyIChqI49QWKfmxEDv9oSXCSyBWiB0"  # Получите у @BotFather
WEB_APP_URL = "https://store.red-1-dark.ru"  # URL веб-приложения

# Роли и их уровни доступа
ROLES = {
    'client': {
        'level': 0,
        'name': 'Покупатель',
        'emoji': '👤',
        'description': 'Обычный пользователь'
    },
    'moderator': {
        'level': 1,
        'name': 'Модератор',
        'emoji': '🛡️',
        'description': 'Помощь клиентам'
    },
    'senior_moderator': {
        'level': 2,
        'name': 'Старший модератор',
        'emoji': '⭐',
        'description': 'Расширенная поддержка'
    },
    'seller': {
        'level': 3,
        'name': 'Продавец',
        'emoji': '💼',
        'description': 'Управление заказами'
    },
    'admin': {
        'level': 4,
        'name': 'Администратор',
        'emoji': '👑',
        'description': 'Полный доступ'
    },
    'owner': {
        'level': 5,
        'name': 'Владелец',
        'emoji': '🔱',
        'description': 'Создатель платформы'
    }
}

# ID владельца (ОБЯЗАТЕЛЬНО ЗАМЕНИТЕ!)
OWNER_ID = 1007096526  # Замените на ваш Telegram ID

# Администраторы (могут назначать роли до admin)
ADMINS = [OWNER_ID]  # ID администраторов

# Пути к файлам данных
DATA_DIR = '../data'
USERS_FILE = os.path.join(DATA_DIR, 'users.json')
SERVICES_FILE = os.path.join(DATA_DIR, 'services.json')
REQUESTS_FILE = os.path.join(DATA_DIR, 'requests.json')
SETTINGS_FILE = os.path.join(DATA_DIR, 'settings.json')
ROLES_FILE = os.path.join(DATA_DIR, 'user_roles.json')

# Инициализация бота
bot = telebot.TeleBot(BOT_TOKEN)

# Утилиты для работы с данными
def load_json(filepath):
    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            return json.load(f)
    except:
        return {}

def save_json(filepath, data):
    os.makedirs(os.path.dirname(filepath), exist_ok=True)
    with open(filepath, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

# Работа с ролями
def get_user_role(telegram_id):
    """Получить роль пользователя"""
    roles_data = load_json(ROLES_FILE)
    
    # Владелец всегда owner
    if telegram_id == OWNER_ID:
        return 'owner'
    
    # Проверяем сохраненную роль
    role = roles_data.get(str(telegram_id), 'client')
    return role

def set_user_role(telegram_id, role):
    """Установить роль пользователя"""
    if role not in ROLES:
        return False
    
    roles_data = load_json(ROLES_FILE)
    roles_data[str(telegram_id)] = role
    save_json(ROLES_FILE, roles_data)
    
    # Обновить в users.json
    users = load_json(USERS_FILE)
    user_id = f"tg_{telegram_id}"
    
    if user_id in users:
        users[user_id]['role'] = role
        users[user_id]['is_seller'] = role in ['seller', 'admin', 'owner']
        save_json(USERS_FILE, users)
    
    return True

def get_role_level(role):
    """Получить уровень доступа роли"""
    return ROLES.get(role, {}).get('level', 0)

def has_permission(telegram_id, required_role):
    """Проверка прав доступа"""
    user_role = get_user_role(telegram_id)
    user_level = get_role_level(user_role)
    required_level = get_role_level(required_role)
    
    return user_level >= required_level

# Декораторы для проверки прав
def require_role(required_role):
    """Декоратор для проверки роли"""
    def decorator(func):
        @wraps(func)
        def wrapper(message):
            if not has_permission(message.from_user.id, required_role):
                role_info = ROLES.get(required_role, {})
                bot.send_message(
                    message.chat.id,
                    f"❌ Недостаточно прав!\n\n"
                    f"Требуется: {role_info.get('emoji', '')} {role_info.get('name', required_role)}"
                )
                return
            return func(message)
        return wrapper
    return decorator

def get_user_by_telegram_id(telegram_id):
    users = load_json(USERS_FILE)
    for user_id, user_data in users.items():
        if user_data.get('telegram_id') == telegram_id:
            return user_id, user_data
    return None, None

def create_or_update_user(telegram_user):
    users = load_json(USERS_FILE)
    user_id = f"tg_{telegram_user.id}"
    
    # Получаем роль пользователя
    role = get_user_role(telegram_user.id)
    
    if user_id not in users:
        users[user_id] = {
            'id': user_id,
            'telegram_id': telegram_user.id,
            'name': f"{telegram_user.first_name} {telegram_user.last_name or ''}".strip(),
            'username': telegram_user.username or f"tg{telegram_user.id}",
            'avatar': '',
            'registered_at': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            'role': role,
            'is_seller': role in ['seller', 'admin', 'owner'],
            'description': ''
        }
        save_json(USERS_FILE, users)
        return users[user_id], True
    
    return users[user_id], False

# Клавиатуры
def get_main_keyboard(telegram_id):
    """Главная клавиатура с учетом роли"""
    keyboard = types.ReplyKeyboardMarkup(resize_keyboard=True)
    role = get_user_role(telegram_id)
    role_info = ROLES.get(role, {})
    
    # Базовые кнопки для всех
    keyboard.row('📋 Мои заявки', '🛍️ Каталог услуг')
    keyboard.row('👤 Профиль', '❓ Помощь')
    
    # Кнопки для модераторов и выше
    if has_permission(telegram_id, 'moderator'):
        keyboard.row('🛡️ Панель модератора')
    
    # Кнопки для продавцов и выше
    if has_permission(telegram_id, 'seller'):
        keyboard.row('💼 Панель продавца')
    
    # Кнопки для админов
    if has_permission(telegram_id, 'admin'):
        keyboard.row('👑 Панель админа')
    
    # Кнопка для владельца
    if role == 'owner':
        keyboard.row('🔱 Панель владельца')
    
    keyboard.row('🌐 Открыть сайт')
    
    return keyboard

def get_moderator_keyboard():
    keyboard = types.ReplyKeyboardMarkup(resize_keyboard=True)
    keyboard.row('📝 Активные заявки', '💬 Чат с клиентами')
    keyboard.row('📊 Статистика', '🔔 Уведомления')
    keyboard.row('◀️ Назад')
    return keyboard

def get_seller_keyboard():
    keyboard = types.ReplyKeyboardMarkup(resize_keyboard=True)
    keyboard.row('📊 Статистика', '📝 Все заявки')
    keyboard.row('👥 Клиенты', '🛍️ Услуги')
    keyboard.row('⚙️ Настройки', '◀️ Назад')
    return keyboard

def get_admin_keyboard():
    keyboard = types.ReplyKeyboardMarkup(resize_keyboard=True)
    keyboard.row('👥 Управление пользователями', '📊 Полная статистика')
    keyboard.row('🛡️ Управление ролями', '📢 Рассылка')
    keyboard.row('⚙️ Настройки системы', '📜 Логи')
    keyboard.row('◀️ Назад')
    return keyboard

def get_owner_keyboard():
    keyboard = types.ReplyKeyboardMarkup(resize_keyboard=True)
    keyboard.row('👑 Назначить админа', '🔱 Все роли')
    keyboard.row('💾 Бэкап данных', '🔄 Перезапуск')
    keyboard.row('📊 Аналитика', '🔐 Безопасность')
    keyboard.row('◀️ Назад')
    return keyboard

# Команды

@bot.message_handler(commands=['start'])
def start(message):
    user, is_new = create_or_update_user(message.from_user)
    role = get_user_role(message.from_user.id)
    role_info = ROLES.get(role, {})
    
    welcome_text = f"""
👋 Добро пожаловать в Red1dark Studio!

{'🎉 Вы успешно зарегистрированы!' if is_new else 'С возвращением!'}

{role_info.get('emoji', '')} Ваша роль: {role_info.get('name', 'Покупатель')}

Я помогу вам:
✅ Просматривать услуги
✅ Оставлять заявки
✅ Отслеживать статус заказов
"""
    
    if has_permission(message.from_user.id, 'moderator'):
        welcome_text += "✅ Помогать клиентам\n"
    
    if has_permission(message.from_user.id, 'seller'):
        welcome_text += "✅ Управлять заказами\n"
    
    if has_permission(message.from_user.id, 'admin'):
        welcome_text += "✅ Управлять системой\n"
    
    welcome_text += "\nВыберите действие из меню ⬇️"
    
    bot.send_message(
        message.chat.id,
        welcome_text,
        reply_markup=get_main_keyboard(message.from_user.id)
    )

@bot.message_handler(commands=['role'])
def check_role(message):
    """Проверить свою роль"""
    role = get_user_role(message.from_user.id)
    role_info = ROLES.get(role, {})
    
    text = f"""
{role_info.get('emoji', '')} *Ваша роль*

Название: {role_info.get('name', 'Неизвестно')}
Уровень: {role_info.get('level', 0)}
Описание: {role_info.get('description', '')}

ID: `{message.from_user.id}`
"""
    
    bot.send_message(message.chat.id, text, parse_mode='Markdown')

@bot.message_handler(commands=['setrole'])
@require_role('admin')
def set_role_command(message):
    """Установить роль пользователю (только админы)"""
    args = message.text.split()
    
    if len(args) != 3:
        bot.send_message(
            message.chat.id,
            "Использование: /setrole <telegram_id> <role>\n\n"
            "Доступные роли:\n" +
            "\n".join([f"- {k}: {v['name']}" for k, v in ROLES.items()])
        )
        return
    
    try:
        target_id = int(args[1])
        new_role = args[2].lower()
        
        if new_role not in ROLES:
            bot.send_message(message.chat.id, "❌ Неизвестная роль!")
            return
        
        # Проверка прав
        user_role = get_user_role(message.from_user.id)
        target_level = get_role_level(new_role)
        user_level = get_role_level(user_role)
        
        # Только owner может назначать admin и owner
        if new_role in ['admin', 'owner'] and user_role != 'owner':
            bot.send_message(message.chat.id, "❌ Только владелец может назначать администраторов!")
            return
        
        # Нельзя назначить роль выше своей
        if target_level >= user_level and user_role != 'owner':
            bot.send_message(message.chat.id, "❌ Нельзя назначить роль выше или равную вашей!")
            return
        
        # Устанавливаем роль
        if set_user_role(target_id, new_role):
            role_info = ROLES[new_role]
            bot.send_message(
                message.chat.id,
                f"✅ Роль установлена!\n\n"
                f"Пользователь: {target_id}\n"
                f"Новая роль: {role_info['emoji']} {role_info['name']}"
            )
            
            # Уведомляем пользователя
            try:
                bot.send_message(
                    target_id,
                    f"🎉 Вам назначена новая роль!\n\n"
                    f"{role_info['emoji']} {role_info['name']}\n"
                    f"{role_info['description']}\n\n"
                    f"Используйте /start для обновления меню"
                )
            except:
                pass
        else:
            bot.send_message(message.chat.id, "❌ Ошибка установки роли!")
            
    except ValueError:
        bot.send_message(message.chat.id, "❌ Неверный формат ID!")

@bot.message_handler(commands=['listroles'])
@require_role('moderator')
def list_roles(message):
    """Список всех ролей"""
    text = "📋 *Доступные роли:*\n\n"
    
    for role_key, role_info in sorted(ROLES.items(), key=lambda x: x[1]['level']):
        text += f"{role_info['emoji']} *{role_info['name']}*\n"
        text += f"Уровень: {role_info['level']}\n"
        text += f"ID: `{role_key}`\n"
        text += f"{role_info['description']}\n\n"
    
    bot.send_message(message.chat.id, text, parse_mode='Markdown')

@bot.message_handler(commands=['staff'])
@require_role('moderator')
def list_staff(message):
    """Список состава команды"""
    roles_data = load_json(ROLES_FILE)
    
    # Группируем по ролям
    staff_by_role = {}
    for tid, role in roles_data.items():
        if role != 'client':
            if role not in staff_by_role:
                staff_by_role[role] = []
            staff_by_role[role].append(tid)
    
    text = "👥 *Состав команды Red1dark Studio*\n\n"
    
    # Сортируем по уровню
    for role_key in sorted(staff_by_role.keys(), key=lambda x: ROLES[x]['level'], reverse=True):
        role_info = ROLES[role_key]
        members = staff_by_role[role_key]
        
        text += f"{role_info['emoji']} *{role_info['name']}* ({len(members)})\n"
        
        for tid in members:
            try:
                # Пытаемся получить имя пользователя
                user_id, user_data = get_user_by_telegram_id(int(tid))
                if user_data:
                    name = user_data.get('name', 'Неизвестно')
                    username = user_data.get('username', '')
                    text += f"  • {name}"
                    if username:
                        text += f" (@{username})"
                    text += f"\n"
                else:
                    text += f"  • ID: {tid}\n"
            except:
                text += f"  • ID: {tid}\n"
        
        text += "\n"
    
    bot.send_message(message.chat.id, text, parse_mode='Markdown')

@bot.message_handler(commands=['help'])
def help_command(message):
    role = get_user_role(message.from_user.id)
    
    help_text = f"""
📖 *Доступные команды:*

*Для всех пользователей:*
/start - Начало работы
/help - Эта справка
/profile - Мой профиль
/role - Моя роль
/services - Каталог услуг
/requests - Мои заявки
/card - Моя визитка
"""
    
    if has_permission(message.from_user.id, 'moderator'):
        help_text += """
*Для модераторов:*
/listroles - Список ролей
/staff - Состав команды
/active - Активные заявки
"""
    
    if has_permission(message.from_user.id, 'seller'):
        help_text += """
*Для продавцов:*
/stats - Статистика
/allrequests - Все заявки
/clients - Список клиентов
"""
    
    if has_permission(message.from_user.id, 'admin'):
        help_text += """
*Для администраторов:*
/setrole - Назначить роль
/broadcast - Рассылка
/backup - Бэкап данных
"""
    
    if role == 'owner':
        help_text += """
*Для владельца:*
/promote - Повысить до админа
/demote - Понизить роль
/system - Системная информация
"""
    
    bot.send_message(message.chat.id, help_text, parse_mode='Markdown')

@bot.message_handler(commands=['stats'])
@require_role('seller')
def stats_command(message):
    """Статистика (продавцы и выше)"""
    users = load_json(USERS_FILE)
    requests = load_json(REQUESTS_FILE)
    services = load_json(SERVICES_FILE)
    
    # Статистика по ролям
    roles_data = load_json(ROLES_FILE)
    role_counts = {}
    for role in ROLES.keys():
        role_counts[role] = sum(1 for r in roles_data.values() if r == role)
    
    stats_counts = {
        'new': sum(1 for r in requests.values() if r.get('status') == 'pending_payment'),
        'paid': sum(1 for r in requests.values() if r.get('status') == 'paid'),
        'active': sum(1 for r in requests.values() if r.get('status') == 'in_progress'),
        'completed': sum(1 for r in requests.values() if r.get('status') == 'completed')
    }
    
    text = f"""
📊 *Статистика Red1dark Studio*

👥 *Пользователи:*
Всего: {len(users)}
"""
    
    for role_key, count in sorted(role_counts.items(), key=lambda x: ROLES[x[0]]['level'], reverse=True):
        if count > 0:
            role_info = ROLES[role_key]
            text += f"{role_info['emoji']} {role_info['name']}: {count}\n"
    
    text += f"""
📝 *Заявки:*
Ожидают оплаты: {stats_counts['new']}
Оплачено: {stats_counts['paid']}
В работе: {stats_counts['active']}
Завершено: {stats_counts['completed']}
Всего: {len(requests)}

🛍️ *Услуги:*
Активных: {sum(1 for s in services.values() if s.get('active'))}
Всего: {len(services)}
"""
    
    keyboard = types.InlineKeyboardMarkup()
    keyboard.add(types.InlineKeyboardButton("🌐 Открыть панель", url=f"{WEB_APP_URL}/seller"))
    
    bot.send_message(message.chat.id, text, parse_mode='Markdown', reply_markup=keyboard)

@bot.message_handler(commands=['promote'])
@require_role('owner')
def promote_command(message):
    """Повысить роль (только owner)"""
    args = message.text.split()
    
    if len(args) != 2:
        bot.send_message(
            message.chat.id,
            "Использование: /promote <telegram_id>\n\n"
            "Повышает роль на один уровень"
        )
        return
    
    try:
        target_id = int(args[1])
        current_role = get_user_role(target_id)
        current_level = get_role_level(current_role)
        
        # Находим следующую роль
        next_role = None
        for role_key, role_info in ROLES.items():
            if role_info['level'] == current_level + 1:
                next_role = role_key
                break
        
        if not next_role:
            bot.send_message(message.chat.id, "❌ Это уже максимальная роль!")
            return
        
        if set_user_role(target_id, next_role):
            new_role_info = ROLES[next_role]
            old_role_info = ROLES[current_role]
            
            bot.send_message(
                message.chat.id,
                f"⬆️ Роль повышена!\n\n"
                f"Пользователь: {target_id}\n"
                f"Было: {old_role_info['emoji']} {old_role_info['name']}\n"
                f"Стало: {new_role_info['emoji']} {new_role_info['name']}"
            )
            
            # Уведомляем пользователя
            try:
                bot.send_message(
                    target_id,
                    f"🎉 Поздравляем с повышением!\n\n"
                    f"Новая роль: {new_role_info['emoji']} {new_role_info['name']}\n"
                    f"Используйте /start для обновления меню"
                )
            except:
                pass
    except:
        bot.send_message(message.chat.id, "❌ Ошибка!")

# Обработка кнопок меню

@bot.message_handler(func=lambda message: message.text == '🛡️ Панель модератора')
@require_role('moderator')
def moderator_panel(message):
    bot.send_message(
        message.chat.id,
        "🛡️ *Панель модератора*\n\nВыберите действие:",
        parse_mode='Markdown',
        reply_markup=get_moderator_keyboard()
    )

@bot.message_handler(func=lambda message: message.text == '💼 Панель продавца')
@require_role('seller')
def seller_panel(message):
    bot.send_message(
        message.chat.id,
        "💼 *Панель продавца*\n\nВыберите действие:",
        parse_mode='Markdown',
        reply_markup=get_seller_keyboard()
    )

@bot.message_handler(func=lambda message: message.text == '👑 Панель админа')
@require_role('admin')
def admin_panel(message):
    bot.send_message(
        message.chat.id,
        "👑 *Панель администратора*\n\nВыберите действие:",
        parse_mode='Markdown',
        reply_markup=get_admin_keyboard()
    )

@bot.message_handler(func=lambda message: message.text == '🔱 Панель владельца')
@require_role('owner')
def owner_panel(message):
    bot.send_message(
        message.chat.id,
        "🔱 *Панель владельца*\n\nВыберите действие:",
        parse_mode='Markdown',
        reply_markup=get_owner_keyboard()
    )

@bot.message_handler(func=lambda message: message.text == '◀️ Назад')
def back_to_main(message):
    start(message)

# Запуск бота
if __name__ == '__main__':
    print("🤖 Бот Red1dark Studio запущен!")
    print(f"🌐 Веб-приложение: {WEB_APP_URL}")
    print(f"🔱 Владелец ID: {OWNER_ID}")
    print(f"👥 Ролевая система активна")
    
    # Создание папок
    os.makedirs(DATA_DIR, exist_ok=True)
    
    # Инициализация файла ролей
    if not os.path.exists(ROLES_FILE):
        save_json(ROLES_FILE, {str(OWNER_ID): 'owner'})
    
    # Запуск polling
    bot.infinity_polling()
