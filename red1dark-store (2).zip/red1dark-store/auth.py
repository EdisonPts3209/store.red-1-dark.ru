# Модуль аутентификации и управления ролями
import os
import json
import random
import string
import time
import smtplib
import ssl
from email.message import EmailMessage
from datetime import datetime, timedelta
from functools import wraps
from werkzeug.security import generate_password_hash, check_password_hash
from flask import session, redirect, url_for, flash

# Константы ролей
ROLES = {
    'owner': {'name': 'Владелец', 'icon': '👑', 'level': 6},
    'system_admin': {'name': 'Системный администратор', 'icon': '🛡', 'level': 5},
    'admin': {'name': 'Администратор', 'icon': '🔧', 'level': 4},
    'seller': {'name': 'Продавец', 'icon': '💼', 'level': 3},
    'buyer': {'name': 'Покупатель', 'icon': '🛒', 'level': 2},
    'guest': {'name': 'Гость', 'icon': '👤', 'level': 1}
}

# Хранилище OTP кодов (в продакшене нужно БД)
OTP_STORAGE = {}

# Простая in-memory защита от брутфорса: хранит метки времени попыток по (ip, action)
RATE_LIMIT = {}

def _cleanup_attempts(key, window):
    now = time.time()
    attempts = RATE_LIMIT.get(key, [])
    attempts = [t for t in attempts if now - t <= window]
    RATE_LIMIT[key] = attempts

def is_rate_limited(ip, action, limit=5, window=300):
    """Проверяет, не превышено ли количество попыток (limit) за window секунд"""
    key = f"{ip}:{action}"
    _cleanup_attempts(key, window)
    return len(RATE_LIMIT.get(key, [])) >= limit

def log_attempt(ip, action):
    key = f"{ip}:{action}"
    RATE_LIMIT.setdefault(key, []).append(time.time())

def verify_captcha(response_token):
    """Проверяет reCAPTCHA token через Google API, если настроен RECAPTCHA_SECRET в env.
    Возвращает True если либо проверка проходит, либо секрет не настроен (dev)."""
    secret = os.getenv('RECAPTCHA_SECRET')
    if not secret:
        return True
    try:
        import requests
        r = requests.post('https://www.google.com/recaptcha/api/siteverify', data={
            'secret': secret,
            'response': response_token
        }, timeout=5)
        data = r.json()
        return data.get('success', False)
    except Exception:
        return False


def generate_otp():
    """Генерирует 6-значный OTP код"""
    return ''.join(random.choices(string.digits, k=6))


def hash_password(password):
    """Хеширует пароль"""
    return generate_password_hash(password, method='pbkdf2:sha256')


def verify_password(stored_hash, password):
    """Проверяет пароль"""
    return check_password_hash(stored_hash, password)


def create_user(email, username, password, role='buyer'):
    """Создаёт нового пользователя"""
    from app import USERS_FILE, save_json, load_json
    
    users = load_json(USERS_FILE)
    
    # Проверка, что используется разрешённый домен
    domain = email.split('@')[1]
    allowed_domains = ['vk.com', 'gmail.com', 'mail.ru', 'yandex.ru']
    
    if domain not in allowed_domains:
        return None, f"Домен {domain} не разрешён. Используйте: {', '.join(allowed_domains)}"
    
    # Проверка уникальности email и username
    for uid, user in users.items():
        if user.get('email') == email or user.get('username') == username:
            return None, "Пользователь с таким email или username уже существует"
    
    user_id = str(len(users) + 1)
    new_user = {
        'id': user_id,
        'email': email,
        'username': username,
        'name': username,
        'password_hash': hash_password(password),
        'role': role,
        'avatar': '',
        'description': '',
        'links': [],
        'created_at': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
        'updated_at': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
        'oauth_providers': {},
        'is_active': False,
        'email_verified': False,
        'blocked': False
    }
    
    users[user_id] = new_user
    save_json(USERS_FILE, users)
    
    return user_id, "Пользователь создан. Проверьте email для подтверждения."


def send_otp_email(email, otp):
    """Отправляет OTP на email (заглушка)"""
    # Если настроен SMTP через .env — отправляем письмо, иначе логируем в консоль
    smtp_server = os.getenv('SMTP_SERVER')
    smtp_port = int(os.getenv('SMTP_PORT', '587'))
    smtp_email = os.getenv('SMTP_EMAIL')
    smtp_password = os.getenv('SMTP_PASSWORD')

    subject = f"Ваш одноразовый код - {otp}"
    body = f"Ваш код для входа: {otp}\nОн действителен {int(os.getenv('OTP_EXPIRY', '600'))//60} минут.\nЕсли вы не запрашивали код, проигнорируйте это сообщение."

    if smtp_server and smtp_email and smtp_password:
        try:
            msg = EmailMessage()
            msg.set_content(body)
            msg['Subject'] = subject
            msg['From'] = smtp_email
            msg['To'] = email

            context = ssl.create_default_context()
            with smtplib.SMTP(smtp_server, smtp_port, timeout=10) as server:
                server.starttls(context=context)
                server.login(smtp_email, smtp_password)
                server.send_message(msg)
            return True
        except Exception as e:
            print(f"[OTP SEND ERROR] {e}")
            # fallback: лог в консоль
            print(f"[OTP CODE]: {otp} для {email}")
            return False
    else:
        print(f"[OTP CODE]: {otp} отправлен на {email} (SMTP не настроен)")
        return False


def verify_otp(email, otp_code):
    """Проверяет OTP код"""
    stored_otp = OTP_STORAGE.get(email)
    
    if not stored_otp:
        return False, "OTP код не найден или истёк"
    
    if stored_otp['code'] != otp_code:
        return False, "Неверный OTP код"
    
    if datetime.now() > stored_otp['expires_at']:
        del OTP_STORAGE[email]
        return False, "OTP код истёк"
    
    del OTP_STORAGE[email]
    return True, "OTP подтверждён"


def get_role_badge(role):
    """Возвращает красивый бейдж роли"""
    if role in ROLES:
        return f"{ROLES[role]['icon']} {ROLES[role]['name']}"
    return "👤 Гость"


def require_login(f):
    """Декоратор для проверки авторизации"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            flash('Необходимо войти в систему', 'warning')
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function


def require_role(required_role):
    """Декоратор для проверки роли"""
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            from app import get_current_user
            
            if 'user_id' not in session:
                flash('Необходимо войти в систему', 'warning')
                return redirect(url_for('login'))
            
            user = get_current_user()
            user_role = user.get('role', 'guest')
            required_level = ROLES.get(required_role, {}).get('level', 0)
            user_level = ROLES.get(user_role, {}).get('level', 0)
            
            if user_level < required_level:
                flash('Недостаточно прав для доступа', 'danger')
                return redirect(url_for('index'))
            
            return f(*args, **kwargs)
        return decorated_function
    return decorator


def assign_role(user_id, new_role, admin_id):
    """Назначает роль пользователю"""
    from app import USERS_FILE, load_json, save_json, get_current_user
    
    admin = None
    if admin_id:
        users = load_json(USERS_FILE)
        admin = users.get(admin_id)
    
    # Владелец может всё
    if admin and admin.get('role') == 'owner':
        users = load_json(USERS_FILE)
        if user_id in users:
            # Нельзя менять владельца
            if users[user_id].get('role') == 'owner':
                return False, "Нельзя менять роль владельца"
            
            users[user_id]['role'] = new_role
            save_json(USERS_FILE, users)
            return True, f"Роль изменена на {ROLES[new_role]['name']}"
    
    # Системный админ может назначать все кроме владельца
    elif admin and admin.get('role') == 'system_admin':
        if new_role == 'owner':
            return False, "Системный админ не может назначать роль владельца"
        
        users = load_json(USERS_FILE)
        if user_id in users:
            users[user_id]['role'] = new_role
            save_json(USERS_FILE, users)
            return True, f"Роль изменена на {ROLES[new_role]['name']}"
    
    # Админ может назначать seller и выше
    elif admin and admin.get('role') == 'admin':
        allowed_roles = ['buyer', 'seller']
        if new_role not in allowed_roles:
            return False, f"Вы можете назначать только: {', '.join(allowed_roles)}"
        
        users = load_json(USERS_FILE)
        if user_id in users:
            users[user_id]['role'] = new_role
            save_json(USERS_FILE, users)
            return True, f"Роль изменена на {ROLES[new_role]['name']}"
    
    return False, "Недостаточно прав для назначения роли"
