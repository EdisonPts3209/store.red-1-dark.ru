"""
Утилиты для работы с SQLite базой данных (замена JSON функциям).
Используется в app.py для работы с пользователями, услугами и заявками.
"""

import json
from datetime import datetime
from models import db, User, Role, Service, Order


def get_current_user_db(user_id):
    """Получает пользователя из БД по ID (может быть int или str username)"""
    if not user_id:
        return None
    
    # Если ID целочисленный (из БД)
    if isinstance(user_id, int):
        return User.query.get(user_id)
    
    # Если строка (username или ID)
    try:
        user_id_int = int(user_id)
        user = User.query.get(user_id_int)
        if user:
            return user
    except:
        pass
    
    # Ищем по username
    return User.query.filter_by(username=str(user_id)).first()


def create_user_db(email, username, password_hash=None, name=None, is_seller=False):
    """Создаёт пользователя в БД"""
    # Проверяем уникальность
    existing = User.query.filter_by(email=email).first()
    if existing:
        return None, "Пользователь с таким email уже существует"
    
    existing = User.query.filter_by(username=username).first()
    if existing:
        return None, "Пользователь с таким username уже существует"
    
    # Получаем роль (buyer по умолчанию)
    role = Role.query.filter_by(name='seller' if is_seller else 'buyer').first()
    
    # Создаём пользователя
    user = User(
        email=email,
        username=username,
        name=name or username,
        password_hash=password_hash or '',
        is_active=True if password_hash else False,
        email_verified=not password_hash,  # OAuth пользователи сразу верифицированы
        is_seller=is_seller
    )
    
    if role:
        user.roles.append(role)
    
    db.session.add(user)
    db.session.commit()
    
    return user, "Пользователь создан"


def get_user_by_email_db(email):
    """Получает пользователя по email"""
    return User.query.filter_by(email=email).first()


def get_user_by_username_db(username):
    """Получает пользователя по username"""
    return User.query.filter_by(username=username).first()


def get_all_services_db(active_only=True):
    """Получает все услуги"""
    query = Service.query
    if active_only:
        query = query.filter_by(is_active=True)
    return query.all()


def get_services_by_category_db(category, active_only=True):
    """Получает услуги по категории"""
    query = Service.query.filter_by(category=category)
    if active_only:
        query = query.filter_by(is_active=True)
    return query.all()


def get_service_db(service_id):
    """Получает услугу по ID"""
    return Service.query.get(service_id)


def create_order_db(user_id, service_id, title, description=None, priority='normal', source='web'):
    """Создаёт заявку (Order) в БД"""
    user = User.query.get(user_id)
    service = Service.query.get(service_id)
    
    if not user or not service:
        return None, "Пользователь или услуга не найдены"
    
    order = Order(
        user_id=user_id,
        service_id=service_id,
        title=title,
        description=description,
        priority=priority,
        source=source,
        amount=service.price,
        status='pending_payment'
    )
    
    db.session.add(order)
    db.session.commit()
    
    return order, "Заявка создана"


def get_user_orders_db(user_id):
    """Получает все заявки пользователя"""
    return Order.query.filter_by(user_id=user_id).all()


def get_order_db(order_id):
    """Получает заявку по ID"""
    return Order.query.get(order_id)


def update_order_status_db(order_id, new_status):
    """Обновляет статус заявки"""
    order = Order.query.get(order_id)
    if order:
        order.status = new_status
        order.updated_at = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        if new_status == 'completed':
            order.completed_at = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        db.session.commit()
        return order, "Статус обновлен"
    return None, "Заявка не найдена"


def user_to_dict(user):
    """Конвертирует объект User в словарь (для JSON ответов и совместимости)"""
    if not user:
        return None
    
    roles = [r.name for r in user.roles] if user.roles else []
    
    return {
        'id': user.id,
        'email': user.email,
        'username': user.username,
        'name': user.name,
        'avatar': user.avatar,
        'description': user.description,
        'roles': roles,
        'is_seller': user.is_seller,
        'is_active': user.is_active,
        'email_verified': user.email_verified,
        'blocked': user.blocked,
        'balance': user.balance,
        'created_at': user.created_at,
        'updated_at': user.updated_at
    }


def service_to_dict(service):
    """Конвертирует объект Service в словарь"""
    if not service:
        return None
    
    return {
        'id': service.id,
        'name': service.name,
        'description': service.description,
        'category': service.category,
        'price': service.price,
        'duration': service.duration,
        'icon': service.icon,
        'is_active': service.is_active
    }


def order_to_dict(order):
    """Конвертирует объект Order в словарь"""
    if not order:
        return None
    
    user = User.query.get(order.user_id)
    service = Service.query.get(order.service_id)
    
    return {
        'id': order.id,
        'user_id': order.user_id,
        'username': user.username if user else 'Unknown',
        'service_id': order.service_id,
        'service_name': service.name if service else 'Unknown',
        'title': order.title,
        'description': order.description,
        'status': order.status,
        'priority': order.priority,
        'amount': order.amount,
        'source': order.source,
        'created_at': order.created_at,
        'updated_at': order.updated_at,
        'completed_at': order.completed_at
    }
