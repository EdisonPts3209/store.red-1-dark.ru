#!/bash
# Скрипт установки и запуска проекта dev

echo "📦 Установка зависимостей..."
pip install -r requirements.txt

echo "✅ Зависимости установлены!"
echo ""
echo "🚀 Запуск приложения..."
echo "Приложение доступно на http://localhost:5000"
echo ""

python app.py
