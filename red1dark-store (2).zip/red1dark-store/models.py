"""
SQLAlchemy модели для Red1dark Studio магазина цифровых услуг.
Использует SQLite с типами данных: TEXT для дат, REAL для баланса.
"""

from datetime import datetime
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import Column, Integer, String, Text, Float, Boolean, DateTime, ForeignKey, Table
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship

db = SQLAlchemy()

# M2M таблица: связь пользователей и ролей
user_roles_table = Table(
    'user_roles',
    db.metadata,
    Column('user_id', Integer, ForeignKey('user.id'), primary_key=True),
    Column('role_id', Integer, ForeignKey('role.id'), primary_key=True)
)

# M2M таблица: связь ролей и прав
role_permissions_table = Table(
    'role_permissions',
    db.metadata,
    Column('role_id', Integer, ForeignKey('role.id'), primary_key=True),
    Column('permission_id', Integer, ForeignKey('permission.id'), primary_key=True)
)


class User(db.Model):
    """Модель пользователя"""
    __tablename__ = 'user'
    
    id = Column(Integer, primary_key=True)
    email = Column(String(255), unique=True, nullable=False)
    username = Column(String(100), unique=True, nullable=False)
    password_hash = Column(String(255), nullable=True)  # null для OAuth пользователей
    name = Column(String(255), nullable=True)
    avatar = Column(Text, nullable=True)  # URL аватара
    description = Column(Text, nullable=True)
    
    # OAuth интеграция
    oauth_providers = Column(Text, nullable=True)  # JSON: {'vk': 'id', 'yandex': 'id', 'telegram': 'id'}
    
    # Статусы
    is_active = Column(Boolean, default=False)
    email_verified = Column(Boolean, default=False)
    blocked = Column(Boolean, default=False)
    is_seller = Column(Boolean, default=False)
    
    # Баланс (для платежей и т.д.)
    balance = Column(Float, default=0.0)  # REAL в SQLite
    
    # Даты (TEXT в SQLite)
    created_at = Column(String(20), default=lambda: datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
    updated_at = Column(String(20), default=lambda: datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
    last_login = Column(String(20), nullable=True)
    
    # Связи
    roles = relationship('Role', secondary=user_roles_table, back_populates='users')
    logs = relationship('UserLog', back_populates='user', cascade='all, delete-orphan')
    auth_tokens = relationship('AuthToken', back_populates='user', cascade='all, delete-orphan')
    orders = relationship('Order', back_populates='user', cascade='all, delete-orphan')
    
    def __repr__(self):
        return f'<User {self.username}>'
    
    def has_role(self, role_name):
        """Проверяет, есть ли у пользователя роль"""
        return any(r.name == role_name for r in self.roles)
    
    def has_permission(self, permission_name):
        """Проверяет, есть ли у пользователя право"""
        for role in self.roles:
            if role.has_permission(permission_name):
                return True
        return False
    
    def get_role_level(self):
        """Возвращает максимальный уровень роли пользователя"""
        if not self.roles:
            return 0
        return max(role.level for role in self.roles)
    
    def add_role(self, role):
        """Добавляет роль пользователю"""
        if not self.has_role(role.name):
            self.roles.append(role)
    
    def remove_role(self, role):
        """Удаляет роль у пользователя"""
        if self in self.roles:
            self.roles.remove(role)


class Role(db.Model):
    """Модель роли пользователя"""
    __tablename__ = 'role'
    
    id = Column(Integer, primary_key=True)
    name = Column(String(50), unique=True, nullable=False)  # 'owner', 'admin', 'seller', 'buyer', 'guest'
    display_name = Column(String(100), nullable=False)  # '👑 Владелец', '🔧 Администратор', и т.д.
    description = Column(Text, nullable=True)
    level = Column(Integer, nullable=False)  # Иерархический уровень (1-6)
    icon = Column(String(10), nullable=True)  # Emoji иконка
    
    # Связи
    users = relationship('User', secondary=user_roles_table, back_populates='roles')
    permissions = relationship('Permission', secondary=role_permissions_table, back_populates='roles')
    
    def __repr__(self):
        return f'<Role {self.name} (level={self.level})>'
    
    def has_permission(self, permission_name):
        """Проверяет, есть ли у роли право"""
        return any(p.name == permission_name for p in self.permissions)
    
    def grant_permission(self, permission):
        """Предоставляет право роли"""
        if not self.has_permission(permission.name):
            self.permissions.append(permission)
    
    def revoke_permission(self, permission):
        """Отзывает право у роли"""
        if permission in self.permissions:
            self.permissions.remove(permission)


class Permission(db.Model):
    """Модель права доступа"""
    __tablename__ = 'permission'
    
    id = Column(Integer, primary_key=True)
    name = Column(String(100), unique=True, nullable=False)  # 'view_admin_panel', 'edit_services', и т.д.
    display_name = Column(String(200), nullable=False)  # '📋 Просмотр админ-панели'
    description = Column(Text, nullable=True)
    category = Column(String(50), nullable=False)  # 'admin', 'seller', 'content', 'moderation', и т.д.
    
    # Связи
    roles = relationship('Role', secondary=role_permissions_table, back_populates='permissions')
    
    def __repr__(self):
        return f'<Permission {self.name}>'


class Service(db.Model):
    """Модель услуги"""
    __tablename__ = 'service'
    
    id = Column(Integer, primary_key=True)
    name = Column(String(255), nullable=False)
    description = Column(Text, nullable=True)
    category = Column(String(50), nullable=False)  # 'telegram', 'web', 'oauth', 'additional'
    price = Column(Float, nullable=False)  # REAL в SQLite
    duration = Column(String(50), nullable=True)  # '5 дней', '15 дней', и т.д.
    icon = Column(String(10), nullable=True)  # Emoji иконка
    is_active = Column(Boolean, default=True)
    
    created_at = Column(String(20), default=lambda: datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
    updated_at = Column(String(20), default=lambda: datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
    
    # Связь с заказами
    orders = relationship('Order', back_populates='service')
    
    def __repr__(self):
        return f'<Service {self.name} ({self.price}₽)>'


class Product(db.Model):
    """Модель продукта (может использоваться для внешних товаров или расширений)"""
    __tablename__ = 'product'
    
    id = Column(Integer, primary_key=True)
    name = Column(String(255), nullable=False)
    description = Column(Text, nullable=True)
    price = Column(Float, nullable=False)  # REAL в SQLite
    quantity = Column(Integer, default=0)
    sku = Column(String(100), unique=True, nullable=True)
    
    created_at = Column(String(20), default=lambda: datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
    updated_at = Column(String(20), default=lambda: datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
    
    def __repr__(self):
        return f'<Product {self.name}>'


class Order(db.Model):
    """Модель заказа (заявка)"""
    __tablename__ = 'order'
    
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey('user.id'), nullable=False)
    service_id = Column(Integer, ForeignKey('service.id'), nullable=False)
    
    title = Column(String(255), nullable=False)
    description = Column(Text, nullable=True)
    
    # Статусы: pending_payment, waiting_response, in_progress, completed, cancelled
    status = Column(String(50), default='pending_payment')
    priority = Column(String(20), default='normal')  # low, normal, high
    
    amount = Column(Float, nullable=False)  # REAL в SQLite
    
    # Источник заявки
    source = Column(String(50), default='web')  # 'web', 'telegram_bot', и т.д.
    
    created_at = Column(String(20), default=lambda: datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
    updated_at = Column(String(20), default=lambda: datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
    completed_at = Column(String(20), nullable=True)
    
    # Связи
    user = relationship('User', back_populates='orders')
    service = relationship('Service', back_populates='orders')
    
    def __repr__(self):
        return f'<Order {self.id} ({self.status})>'


class UserLog(db.Model):
    """Модель логирования действий пользователя"""
    __tablename__ = 'user_log'
    
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey('user.id'), nullable=False)
    
    action = Column(String(100), nullable=False)  # 'login', 'logout', 'create_order', и т.д.
    resource = Column(String(100), nullable=True)  # Что было затронуто (order_id, service_id, и т.д.)
    details = Column(Text, nullable=True)  # JSON с деталями
    
    ip_address = Column(String(50), nullable=True)
    user_agent = Column(Text, nullable=True)
    
    created_at = Column(String(20), default=lambda: datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
    
    # Связь
    user = relationship('User', back_populates='logs')
    
    def __repr__(self):
        return f'<UserLog {self.action} by user {self.user_id}>'


class AuthToken(db.Model):
    """Модель токена авторизации (для OAuth и API)"""
    __tablename__ = 'auth_token'
    
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey('user.id'), nullable=False)
    
    token = Column(String(500), unique=True, nullable=False)
    provider = Column(String(50), nullable=False)  # 'vk', 'yandex', 'telegram', 'jwt_api'
    provider_user_id = Column(String(200), nullable=True)  # ID в системе провайдера
    
    access_token = Column(Text, nullable=True)  # Токен доступа от провайдера
    refresh_token = Column(Text, nullable=True)  # Refresh token (если есть)
    
    is_active = Column(Boolean, default=True)
    
    created_at = Column(String(20), default=lambda: datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
    expires_at = Column(String(20), nullable=True)  # Когда истекает токен
    last_used = Column(String(20), nullable=True)
    
    # Связь
    user = relationship('User', back_populates='auth_tokens')
    
    def __repr__(self):
        return f'<AuthToken {self.provider} for user {self.user_id}>'
