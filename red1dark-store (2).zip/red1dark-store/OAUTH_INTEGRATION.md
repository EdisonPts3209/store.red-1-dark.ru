# 🔐 Интеграция OAuth и Telegram Widget

## Краткая справка

Система поддерживает три способа входа через соцсети:

1. **VK (ВКонтакте)** - классический OAuth
2. **Yandex (Яндекс)** - классический OAuth  
3. **Telegram Widget** - специальный виджет входа от Telegram (не классический OAuth)

---

## 1️⃣ VK OAuth

### Получение ключей

1. Перейдите на [https://vk.com/apps](https://vk.com/apps)
2. Создайте новое приложение типа "Standalone"
3. В разделе Settings найдите:
   - **App ID** → `VK_CLIENT_ID` в `.env`
   - **Secure key** → `VK_CLIENT_SECRET` в `.env`

### Настройка redirect URI

1. В приложении VK перейдите в **Settings** → **Authorization**
2. Добавьте в "Authorized redirect URIs":
   ```
   https://your-domain.com/auth/vk/callback
   ```
   (В dev используйте `http://localhost:5000/auth/vk/callback`)

### Конфигурация

```env
VK_CLIENT_ID=123456789
VK_CLIENT_SECRET=your-secret-key-here
VK_REDIRECT_URI=https://your-domain.com/auth/vk/callback
```

### Тестирование

После сохранения cредств, кнопка VK появится на странице входа/регистрации.

---

## 2️⃣ Yandex OAuth

### Получение ключей

1. Перейдите на [https://oauth.yandex.ru](https://oauth.yandex.ru)
2. Создайте новое приложение (тип: Web application)
3. Заполните информацию об приложении
4. Получите:
   - **Client ID** → `YANDEX_CLIENT_ID` в `.env`
   - **Client Secret** → `YANDEX_CLIENT_SECRET` в `.env`

### Настройка redirect URI

1. В Yandex OAuth admin перейдите в **Callback URLs**
2. Добавьте:
   ```
   https://your-domain.com/auth/yandex/callback
   ```

### Конфигурация

```env
YANDEX_CLIENT_ID=abc123def456
YANDEX_CLIENT_SECRET=your-secret-key-here
YANDEX_REDIRECT_URI=https://your-domain.com/auth/yandex/callback
```

---

## 3️⃣ Telegram Widget Login

Telegram Widget — это **НЕ классический OAuth**. Это специальный виджет, который:
- Требует только `TELEGRAM_BOT_TOKEN` и `TELEGRAM_BOT_USERNAME`
- Работает через подпись (HMAC-SHA256)
- Пользователь получает готовые данные с клиента
- Сервер проверяет подпись

### Получение данных бота

1. Напишите в Telegram: [@BotFather](https://t.me/botfather)
2. Выполните команды:
   ```
   /newbot
   Введите название бота (например: Red1dark Store)
   Введите username (например: red1dark_store_bot)
   ```
3. BotFather даст вам **Bot Token** (долгая строка с двоеточием)
4. Bot Token → `TELEGRAM_BOT_TOKEN` в `.env`
5. Username (без @) → `TELEGRAM_BOT_USERNAME` в `.env`

### Конфигурация

```env
TELEGRAM_BOT_TOKEN=123456789:ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghi
TELEGRAM_BOT_USERNAME=red1dark_store_bot
```

### Как это работает

1. Пользователь нажимает кнопку "Telegram" на странице входа
2. Загружается Telegram Widget скрипт со встроенным username бота
3. Кликнув, пользователь авторизуется в Telegram
4. Telegram отправляет подписанные данные пользователя
5. Наш сервер проверяет подпись через `HMAC-SHA256(token, data)`
6. Если подпись верна и давность < 1 часа, пользователь логируется

---

## 📋 Полный пример .env

```env
# OAuth VK
VK_CLIENT_ID=123456789
VK_CLIENT_SECRET=your-vk-secret
VK_REDIRECT_URI=https://yourdomain.com/auth/vk/callback

# OAuth Yandex  
YANDEX_CLIENT_ID=abc123def456
YANDEX_CLIENT_SECRET=your-yandex-secret
YANDEX_REDIRECT_URI=https://yourdomain.com/auth/yandex/callback

# Telegram Widget
TELEGRAM_BOT_TOKEN=123456789:ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghi
TELEGRAM_BOT_USERNAME=red1dark_store_bot
```

---

## 🧪 Тестирование локально

### Для VK и Yandex

Используйте **ngrok** для создания публичного URL:

```bash
# Установить ngrok (если нет)
pip install pyngrok
# или скачать с https://ngrok.com

# Запустить ngrok
ngrok http 5000

# Вы получите http://abc123.ngrok.io
# Используйте в redirect_uri:
# https://abc123.ngrok.io/auth/vk/callback
# https://abc123.ngrok.io/auth/yandex/callback
```

Обновите `.env`:
```env
VK_REDIRECT_URI=https://abc123.ngrok.io/auth/vk/callback
YANDEX_REDIRECT_URI=https://abc123.ngrok.io/auth/yandex/callback
```

### Для Telegram Widget

Telegram Widget работает **везде**, включая localhost, потому что основан на подписи, а не на redirect.

---

## 🔄 Процесс входа

### VK/Yandex OAuth Flow

```
1. Пользователь нажимает кнопку VK/Yandex
2. Перенаправляется на oauth.vk.com / oauth.yandex.ru
3. Вводит пароль (если нужно)
4. Возвращается на /auth/vk/callback или /auth/yandex/callback с кодом
5. Сервер обменивает код на access_token
6. Получает данные пользователя
7. Логирует пользователя
```

### Telegram Widget Flow

```
1. Пользователь нажимает кнопку Telegram
2. Загружается Telegram Widget скрипт
3. Открывается Telegram в новом окне (или в приложении)
4. Пользователь одобряет доступ
5. Telegram отправляет подписанные данные
6. Сервер проверяет подпись
7. Логирует пользователя
```

---

## 🛡️ Безопасность

✅ **Сделано:**
- Проверка подписей (Telegram Widget)
- Защита состояния
- Rate limiting
- HTTPS enforce (в продакшене)

⚠️ **Помните:**
- **SECRET_KEY** в app.py должен быть секретным
- OAuth credentials хранятся в `.env` (никогда не выкладывайте!)
- Telegram Widget проверяет давность (< 1 часа)

---

## 🐛 Troubleshoot

### "Client не настроен"

```
Ошибка: "VK OAuth не настроен"
```

**Решение:** Убедитесь что в `.env` заполнены:
- `VK_CLIENT_ID`
- `VK_CLIENT_SECRET`

### "Неверная подпись" (Telegram)

```
Ошибка: verify_telegram_widget возвращает False
```

**Проверьте:**
- `TELEGRAM_BOT_TOKEN` скопирован правильно
- Подпись проходит проверку HMAC-SHA256
- Данные актуальны (< 1 часа со времени `auth_date`)

### Redirect URI не совпадает

```
Ошибка от VK/Yandex: "redirect_uri не совпадает"
```

**Решение:**
- Check `.env`: `VK_REDIRECT_URI` должна быть идентична в приложении VK/Yandex
- В продакшене используйте https://your-domain.com
- В dev используйте http://localhost:5000

---

## 📞 Справочники

- VK OAuth: https://dev.vk.com/reference/oauth-get-access-token
- Yandex OAuth: https://yandex.ru/dev/id/doc/ru/oauth/client-credentials-flow
- Telegram Widget Login: https://core.telegram.org/widgets/login
- Telegram Bot API: https://core.telegram.org/bots/api

