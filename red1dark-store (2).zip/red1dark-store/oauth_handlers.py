# OAuth интеграции и их обработчики
# Этот файл содержит примеры и функции помощи для OAuth VK, Яндекс и Telegram Widget

import hashlib
import hmac
import os
import requests
import json
from datetime import datetime

def verify_telegram_widget(auth_data):
    """
    Проверяет подпись Telegram Widget Login.
    
    auth_data: dict с полями из Telegram Widget
    {
        'id': user_id,
        'first_name': 'Name',
        'auth_date': timestamp,
        'hash': calculated_hash
    }
    """
    bot_token = os.getenv('TELEGRAM_BOT_TOKEN', '')
    if not bot_token:
        return False, "Telegram bot token не настроен"
    
    # Подготавливаем данные для проверки подписи
    data_check_string = '\n'.join(f"{k}={v}" for k, v in sorted(auth_data.items()) if k != 'hash')
    secret_key = hashlib.sha256(bot_token.encode()).digest()
    
    calc_hash = hmac.new(secret_key, data_check_string.encode(), hashlib.sha256).hexdigest()
    
    if calc_hash == auth_data.get('hash'):
        # Проверяем давность (не старше 1 часа)
        auth_timestamp = int(auth_data.get('auth_date', 0))
        now = int(datetime.now().timestamp())
        if now - auth_timestamp < 3600:
            return True, None
        return False, "Auth данные устарели"
    return False, "Неверная подпись"


def get_vk_user(access_token):
    """
    Получает данные пользователя VK.
    
    Документация: https://dev.vk.com/reference/users-get
    """
    try:
        response = requests.get('https://api.vk.com/method/users.get', params={
            'access_token': access_token,
            'fields': 'photo_100,city',
            'v': '5.131'
        }, timeout=10)
        data = response.json()
        
        if 'error' in data:
            return None, data['error'].get('error_msg', 'VK API error')
        
        if data.get('response'):
            user = data['response'][0]
            return user, None
        
        return None, "Неверный ответ от VK API"
    except Exception as e:
        return None, str(e)


def get_yandex_user(access_token):
    """
    Получает данные пользователя Yandex.
    
    Документация: https://yandex.ru/dev/id/doc/ru/user-account/user-account
    """
    try:
        response = requests.get('https://login.yandex.ru/info', headers={
            'Authorization': f'OAuth {access_token}'
        }, timeout=10)
        data = response.json()
        
        if 'error' in data:
            return None, data.get('error', 'Yandex API error')
        
        return data, None
    except Exception as e:
        return None, str(e)


def exchange_vk_code(code, redirect_uri):
    """
    Обменивает код на access_token для VK OAuth.
    
    Документация: https://dev.vk.com/reference/oauth-get-access-token
    """
    client_id = os.getenv('VK_CLIENT_ID')
    client_secret = os.getenv('VK_CLIENT_SECRET')
    
    if not client_id or not client_secret:
        return None, "VK OAuth не настроен"
    
    try:
        response = requests.get('https://oauth.vk.com/access_token', params={
            'client_id': client_id,
            'client_secret': client_secret,
            'redirect_uri': redirect_uri,
            'code': code
        }, timeout=10)
        data = response.json()
        
        if 'error' in data:
            return None, data.get('error_description', 'VK OAuth error')
        
        access_token = data.get('access_token')
        user_id = data.get('user_id')
        return access_token, None
    except Exception as e:
        return None, str(e)


def exchange_yandex_code(code, redirect_uri):
    """
    Обменивает код на access_token для Yandex OAuth.
    
    Документация: https://yandex.ru/dev/id/doc/ru/oauth/client-credentials-flow
    """
    client_id = os.getenv('YANDEX_CLIENT_ID')
    client_secret = os.getenv('YANDEX_CLIENT_SECRET')
    
    if not client_id or not client_secret:
        return None, "Yandex OAuth не настроен"
    
    try:
        response = requests.post('https://oauth.yandex.ru/token', data={
            'grant_type': 'authorization_code',
            'code': code,
            'client_id': client_id,
            'client_secret': client_secret,
            'redirect_uri': redirect_uri
        }, timeout=10)
        data = response.json()
        
        if 'error' in data:
            return None, data.get('error_description', 'Yandex OAuth error')
        
        access_token = data.get('access_token')
        return access_token, None
    except Exception as e:
        return None, str(e)
