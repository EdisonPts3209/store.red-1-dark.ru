# 🚀 РАЗВЁРТЫВАНИЕ НА ХОСТ - Red1dark Studio v2.0

**Это финальный гайд для развёртывания на продакшене на любом хосте.**

---

## 📋 ПЕРЕД ЗАПУСКОМ

Убедитесь, что у вас есть:
- [ ] Доступ по SSH на хост
- [ ] Python 3.8+ установлен
- [ ] Domain с поддержкой SSL (https://)
- [ ] VK OAuth ключи (если используете)
- [ ] Telegram Bot Token (если используете)
- [ ] Аккаунт в банке для платежей (СБП/Альфа-банк)

---

## 🔧 ЭТАП 1: ПОДГОТОВКА СЕРВЕРА

### 1.1 Обновление системы
```bash
apt update && apt upgrade -y
```

### 1.2 Установка Python и зависимостей
```bash
apt install -y python3 python3-pip python3-venv git curl
```

### 1.3 Установка Nginx (web-server)
```bash
apt install -y nginx
```

### 1.4 Установка Supervisor (процесс-менеджер)
```bash
apt install -y supervisor
```

### 1.5 Создание пользователя для приложения
```bash
useradd -m red1dark
usermod -aG sudo red1dark
```

---

## 📥 ЭТАП 2: ЗАГРУЗКА И ПОДГОТОВКА ПРИЛОЖЕНИЯ

### 2.1 Клонирование репозитория
```bash
cd /home/red1dark
git clone <URL вашего репозитория> app
cd app
```

Или если нет git, загрузите файлы через FTP/SCP:
```bash
# Если фнкономьте через SCP (с вашего ПК):
scp -r ./red1dark-store/* root@yourdomain.com:/home/red1dark/app/
```

### 2.2 Создание виртуального окружения
```bash
cd /home/red1dark/app
python3 -m venv venv
source venv/bin/activate
```

### 2.3 Установка зависимостей
```bash
pip install --upgrade pip
pip install -r requirements.txt
```

### 2.4 Создание папки data
```bash
mkdir -p data
```

---

## 🔐 ЭТАП 3: НАСТРОЙКА ПЕРЕМЕННЫХ ОКРУЖЕНИЯ

### 3.1 Создание .env файла

```bash
touch .env
nano .env  # или vi .env
```

Добавьте следующее:

```ini
# ОСНОВНЫЕ НАСТРОЙКИ
FLASK_ENV=production
DEBUG=False
SECRET_KEY=generate-random-string-here-min-32-chars
HOST=0.0.0.0
PORT=5000

# VK OAuth (ОПЦИОНАЛЬНО)
VK_CLIENT_ID=your-vk-app-id
VK_CLIENT_SECRET=your-vk-secret
VK_REDIRECT_URI=https://yourdomain.com/auth/vk/callback

# TELEGRAM (ОПЦИОНАЛЬНО)
TELEGRAM_BOT_TOKEN=your-telegram-token
TELEGRAM_CLIENT_ID=your-telegram-app-id

# EMAIL OTP (ОПЦИОНАЛЬНО)
SMTP_SERVER=smtp.gmail.com
SMTP_PORT=587
SMTP_EMAIL=your-email@gmail.com
SMTP_PASSWORD=your-app-password
OTP_EXPIRY=600
```

### Где взять SECRET_KEY?

```bash
python3 -c "import secrets; print(secrets.token_hex(32))"
```

Скопируйте результат в SECRET_KEY.

### 3.2 Защита .env файла
```bash
chmod 600 .env
```

---

## 🌐 ЭТАП 4: НАСТРОЙКА NGINX

### 4.1 Создание конфигурации Nginx

```bash
sudo nano /etc/nginx/sites-available/red1dark-studio
```

Вставьте следующее (замените yourdomain.com на ваш домен):

```nginx
server {
    listen 80;
    listen [::]:80;
    server_name yourdomain.com www.yourdomain.com;

    # Редирект на HTTPS
    return 301 https://$server_name$request_uri;
}

server {
    listen 443 ssl http2;
    listen [::]:443 ssl http2;
    server_name yourdomain.com www.yourdomain.com;

    # SSL сертификат (установите Let's Encrypt - см. ниже)
    ssl_certificate /etc/letsencrypt/live/yourdomain.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/yourdomain.com/privkey.pem;

    # Безопасность SSL
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_ciphers HIGH:!aNULL:!MD5;
    ssl_prefer_server_ciphers on;

    client_max_body_size 10M;

    location / {
        proxy_pass http://127.0.0.1:5000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_read_timeout 60s;
    }

    location /static/ {
        alias /home/red1dark/app/static/;
        expires 30d;
        add_header Cache-Control "public, immutable";
    }
}
```

### 4.2 Включение конфигурации
```bash
sudo ln -s /etc/nginx/sites-available/red1dark-studio /etc/nginx/sites-enabled/
sudo nginx -t  # Проверка синтаксиса
sudo systemctl restart nginx
```

---

## 🔒 ЭТАП 5: УСТАНОВКА SSL (Let's Encrypt)

### 5.1 Установка Certbot
```bash
apt install -y certbot python3-certbot-nginx
```

### 5.2 Получение сертификата
```bash
certbot certonly --nginx -d yourdomain.com -d www.yourdomain.com
```

### 5.3 Автоматическое обновление
```bash
systemctl enable certbot.timer
systemctl start certbot.timer
```

---

## ⚙️ ЭТАП 6: НАСТРОЙКА SUPERVISOR

### 6.1 Создание конфига Supervisor
```bash
sudo nano /etc/supervisor/conf.d/red1dark-studio.conf
```

Вставьте:

```ini
[program:red1dark-studio]
directory=/home/red1dark/app
command=/home/red1dark/app/venv/bin/gunicorn -w 4 -b 127.0.0.1:5000 app:app
user=red1dark
autostart=true
autorestart=true
redirect_stderr=true
stdout_logfile=/home/red1dark/app/logs/gunicorn.log
environment=PATH="/home/red1dark/app/venv/bin"

[group:red1dark]
programs=red1dark-studio
priority=999
```

### 6.2 Создание папки логов
```bash
mkdir -p /home/red1dark/app/logs
chown red1dark:red1dark /home/red1dark/app/logs
```

### 6.3 Запуск Supervisor
```bash
sudo supervisorctl reread
sudo supervisorctl update
sudo supervisorctl start red1dark-studio
```

### 6.4 Проверка статуса
```bash
sudo supervisorctl status red1dark-studio
```

---

## 🧪 ЭТАП 7: ТЕСТИРОВАНИЕ

### 7.1 Проверка приложения локально
```bash
curl http://127.0.0.1:5000
```

Должно вернуть HTML страницу.

### 7.2 Проверка через Nginx
```bash
curl https://yourdomain.com
```

Должно вернуть HTML страницу.

### 7.3 Открытие браузера
Откройте https://yourdomain.com и проверьте:
- [ ] Главная страница отображается
- [ ] Может зарегистрироваться новый пользователь
- [ ] Может войти с email и паролем
- [ ] Админ-панель доступна (если вы администратор)

---

## 🐛 ДИАГНОСТИКА ПРОБЛЕМ

### Приложение не запускается

```bash
# Проверка логов Supervisor
sudo tail -f /var/log/supervisor/red1dark-studio.log

# Проверка логов Nginx
sudo tail -f /var/log/nginx/error.log
```

### Ошибка подключения к БД
```bash
# Проверка прав доступа к папке data
ls -la /home/red1dark/app/data/
```

### Ошибка SSL
```bash
# Проверка сертификата
sudo certbot certificates

# Обновление сертификата
sudo certbot renew
```

### Порт уже занят
```bash
# Проверка процессов на порту 5000
lsof -i :5000

# Если нужно, убейте процесс
kill -9 <PID>
```

---

## 📊 监-ПАНЕЛЬ (МОНИТОРИНГ)

### Просмотр логов в реальном времени
```bash
sudo tail -f /home/red1dark/app/logs/gunicorn.log
```

### Проверка использования памяти
```bash
ps aux | grep red1dark-studio
```

### Создание резервных копий данных
```bash
# Резервная копия БД каждые сутки
0 2 * * * tar -czf /backups/red1dark-$(date +\%Y\%m\%d).tar.gz /home/red1dark/app/data/
```

---

## 🔄 ОБНОВЛЕНИЯ

### Обновление приложения

```bash
cd /home/red1dark/app
git pull origin main  # или загрузите новые файлы через SCP

# Обновление зависимостей
source venv/bin/activate
pip install -r requirements.txt

# Перезагрузка приложения
sudo supervisorctl restart red1dark-studio
```

---

## 🚀 ФИНАЛЬНАЯ ПРОВЕРКА

Убедитесь, что:
- ✅ Приложение запускается без ошибок
- ✅ SSL работает (зелёный замок в браузере)
- ✅ Можно зарегистрироваться
- ✅ Можно войти
- ✅ Админ-панель доступна
- ✅ Могу видеть услуги и цены
- ✅ Логи не содержат ошибок

---

## 📞 ЕСЛИ ЧТО-ТО НЕ РАБОТАЕТ

1. Проверьте логи: `sudo tail -f /var/log/supervisor/red1dark-studio.log`
2. Проверьте .env файл - все ли ключи заполнены?
3. Перезагрузите: `sudo supervisorctl restart red1dark-studio`
4. Свяжитесь: [@red1dark](https://t.me/red1dark)

---

## 💡 СОВЕТЫ

1. **Используйте PM2 вместо Supervisor** (если удобнее)
2. **Включите logrotate** для сжатия старых логов
3. **Используйте CloudFlare** для DDoS защиты
4. **Регулярно обновляйте** SSL сертификаты
5. **Монируте** процессы через Systemd или другой инструмент

---

**Готово к развёртыванию!** 🎉

Если возникли вопросы - пишите: [@red1dark](https://t.me/red1dark)
