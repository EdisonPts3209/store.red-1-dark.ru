# ⚙️ Яндекс OAuth - Пошаговая настройка

## 1️⃣ Создание приложения (Шаг 1-2)

Вы на **Шаг 2 из 4** - "Платформы приложений"

### Что делать:

1. **Веб-сервисы** - уже выбрано ✓

2. **Redirect URI** - добавьте:
   ```
   https://your-domain.com/auth/yandex/callback
   ```
   (В dev используйте: `http://localhost:5000/auth/yandex/callback`)
   
   Нажмите `+` чтобы добавить

3. **Suggest Hostname** - можете оставить пусто или заполнить хост

4. Пропустите **iOS-приложение** и **Android-приложение** (они не нужны)

5. Нажмите **Далее** (кнопка внизу)

---

## 2️⃣ Получение ключей (Шаг 3-4)

После завершения всех шагов вы получите:

- **Client ID** (ID приложения)
- **Client Secret** (Пароль приложения)

### Скопируйте оба значения!

---

## 3️⃣ Обновление .env

Откройте `.env` в вашем проекте и заполните:

```env
YANDEX_CLIENT_ID=your-client-id-здесь
YANDEX_CLIENT_SECRET=your-client-secret-здесь
YANDEX_REDIRECT_URI=https://your-domain.com/auth/yandex/callback
```

### Пример (не реальные значения):
```env
YANDEX_CLIENT_ID=a1b2c3d4e5f6g7h8
YANDEX_CLIENT_SECRET=7h8g9f0e1d2c3b4a
YANDEX_REDIRECT_URI=https://yourdomain.com/auth/yandex/callback
```

---

## 4️⃣ Тестирование

После сохранения `.env`:

1. Перезагрузите приложение (или restart сервера)
2. Перейдите на страницу входа: http://localhost:5000/login
3. Нажмите кнопку "🔴 Яндекс"
4. Должны перенаправить на oauth.yandex.ru
5. Вводите логин/пароль Яндекса
6. После одобрения вернутся на сайт с новым пользователем

---

## ⚠️ Важные моменты

### Redirect URI должен совпадать!

❌ **НЕПРАВИЛЬНО:**
- В Яндексе: `https://domain.com/auth/yandex/callback`
- В коде: `http://localhost/auth/yandex/callback`

✅ **ПРАВИЛЬНО:**
- В Яндексе: `https://your-domain.com/auth/yandex/callback`
- В коде: `https://your-domain.com/auth/yandex/callback`

### Протокол должен совпадать (http vs https)

### Для локального тестирования используйте ngrok

```bash
ngrok http 5000
# Получите https://abc123.ngrok.io

# Добавьте в Яндекс:
# https://abc123.ngrok.io/auth/yandex/callback

# Обновите .env:
YANDEX_REDIRECT_URI=https://abc123.ngrok.io/auth/yandex/callback
```

---

## 🔗 Ссылки

- Яндекс OAuth пллатформа: https://oauth.yandex.ru
- Документация: https://yandex.ru/dev/id/doc/ru/oauth/client-credentials-flow
- Получение ключей: После создания приложения в "Параметры" вкладке

---

## ✅ Проверка

Когда заполните `.env`, запустите и проверьте:

```bash
python app.py
# Перейти http://localhost:5000/login
# Нажать "Яндекс" и авторизоваться
```

Если всё верно, вы должны залогиться и создастся пользователь!

---

**Отправьте мне полученные значения и я их вставлю в `.env`** (или вставьте сами в `.env` и `.env.example`)
