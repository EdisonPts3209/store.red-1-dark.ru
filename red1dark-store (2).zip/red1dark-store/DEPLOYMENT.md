# 🚀 Инструкция по развёртыванию Red1dark Studio на REG.RU

## 📋 Содержание
1. Подготовка хостинга
2. Загрузка файлов
3. Настройка окружения
4. Установка зависимостей
5. Настройка OAuth (VK и Telegram)
6. Настройка платежей
7. Запуск приложения

---

## 1️⃣ Подготовка хостинга на REG.RU

### Требования:
- **Хостинг**: VPS/VDS или виртуальный хостинг с поддержкой Python 3.8+
- **Домен**: red-1-dark.ru (главный) и store.red-1-dark.ru (магазин)
- **SSL сертификат**: Let's Encrypt (бесплатный)

### Шаги:
1. Войдите в панель управления REG.RU
2. Настройте DNS записи:
   - Добавьте A-запись для `red-1-dark.ru` → IP вашего сервера
   - Добавьте A-запись для `store.red-1-dark.ru` → IP вашего сервера

---

## 2️⃣ Загрузка файлов

### Через FTP/SFTP:
```bash
# Подключитесь к серверу через FileZilla или другой FTP-клиент
# Загрузите все файлы проекта в директорию:
/var/www/red1dark-store/
```

### Через SSH:
```bash
# Подключитесь к серверу
ssh user@your-server-ip

# Перейдите в директорию
cd /var/www/

# Клонируйте проект (если используете git)
git clone <ваш-репозиторий> red1dark-store

# Или загрузите файлы через scp
scp -r /local/path/red1dark-store user@your-server-ip:/var/www/
```

---

## 3️⃣ Настройка окружения

### Создайте виртуальное окружение:
```bash
cd /var/www/red1dark-store
python3 -m venv venv
source venv/bin/activate
```

### Установите зависимости:
```bash
pip install flask
```

Создайте файл `requirements.txt`:
```txt
Flask==3.0.0
Werkzeug==3.0.1
```

Установите:
```bash
pip install -r requirements.txt
```

---

## 4️⃣ Настройка OAuth

### VK OAuth:
1. Перейдите на https://vk.com/apps?act=manage
2. Создайте новое приложение
3. Получите `client_id` и `client_secret`
4. Укажите Redirect URI: `https://store.red-1-dark.ru/auth/vk/callback`

### Telegram OAuth:
1. Напишите @BotFather в Telegram
2. Создайте бота командой `/newbot`
3. Получите токен бота
4. Настройте OAuth через Telegram Login Widget
5. Укажите домен: `store.red-1-dark.ru`

### Добавьте в app.py:
```python
# VK OAuth настройки
VK_CLIENT_ID = 'ваш_client_id'
VK_CLIENT_SECRET = 'ваш_client_secret'

# Telegram OAuth настройки
TELEGRAM_BOT_TOKEN = 'ваш_telegram_bot_token'
```

**❗ ВАЖНО:** Вы (клиент) самостоятельно получаете эти ключи. Разработчик только подключает их в коде.

---

## 5️⃣ Настройка платежей

### СБП / Эквайринг:
1. **Разработчик НЕ настраивает банки и платежи**
2. **Вы самостоятельно**:
   - Заходите в личный кабинет вашего банка
   - Подключаете эквайринг или СБП
   - Получаете API ключи
   - Предоставляете их разработчику для интеграции в код

### Разработчик создаст:
- Обработчики webhook от банка
- Страницы "Оплата успешна" / "Ошибка"
- Обновление статуса заявки после оплаты

### Примеры интеграций (код добавит разработчик):
```python
# Пример webhook от банка
@app.route('/payment/webhook', methods=['POST'])
def payment_webhook():
    # Обработка уведомления от банка
    # Проверка подписи
    # Обновление статуса заявки
    pass
```

---

## 6️⃣ Запуск приложения

### Вариант 1: Gunicorn (рекомендуется для продакшена)
```bash
pip install gunicorn

# Запуск
gunicorn -w 4 -b 0.0.0.0:8000 app:app
```

### Вариант 2: Systemd сервис
Создайте файл `/etc/systemd/system/red1dark.service`:
```ini
[Unit]
Description=Red1dark Studio
After=network.target

[Service]
User=www-data
WorkingDirectory=/var/www/red1dark-store
Environment="PATH=/var/www/red1dark-store/venv/bin"
ExecStart=/var/www/red1dark-store/venv/bin/gunicorn -w 4 -b 127.0.0.1:8000 app:app

[Install]
WantedBy=multi-user.target
```

Запустите:
```bash
sudo systemctl daemon-reload
sudo systemctl start red1dark
sudo systemctl enable red1dark
```

---

## 7️⃣ Настройка Nginx (веб-сервер)

Создайте конфигурацию `/etc/nginx/sites-available/red1dark`:
```nginx
server {
    listen 80;
    server_name store.red-1-dark.ru;

    location / {
        proxy_pass http://127.0.0.1:8000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    }

    location /static {
        alias /var/www/red1dark-store/static;
        expires 30d;
    }
}
```

Активируйте:
```bash
sudo ln -s /etc/nginx/sites-available/red1dark /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl reload nginx
```

---

## 8️⃣ Настройка SSL (Let's Encrypt)

```bash
sudo apt install certbot python3-certbot-nginx
sudo certbot --nginx -d store.red-1-dark.ru
```

---

## 9️⃣ Демо-вход (для разработки)

В текущей версии есть демо-авторизация для тестирования:
- Войти как покупатель: введите любой username
- Войти как продавец: используйте username `seller`

**В продакшене** замените на настоящий OAuth VK и Telegram.

---

## 🔟 Важные моменты

### ❗ Что делает РАЗРАБОТЧИК:
- ✅ Пишет код приложения
- ✅ Подключает OAuth в коде (после получения ключей от клиента)
- ✅ Создаёт обработчики платежей
- ✅ Даёт инструкции по настройке

### ❗ Что делает КЛИЕНТ (ВЫ):
- ✅ Получает client_id и client_secret для OAuth
- ✅ Настраивает банковский эквайринг в своём банке
- ✅ Получает API ключи от банка
- ✅ Настраивает хостинг и домены
- ✅ Запускает приложение на сервере

### ❌ Разработчик НЕ ДЕЛАЕТ:
- ❌ Не работает с банками
- ❌ Не настраивает эквайринг
- ❌ Не покупает хостинг/домены
- ❌ Не настраивает SSL (кроме инструкций)

---

## 📞 Поддержка

При возникновении проблем:
1. Проверьте логи: `sudo journalctl -u red1dark -f`
2. Проверьте статус: `sudo systemctl status red1dark`
3. Свяжитесь с разработчиком для исправления кода

---

## ❤️ Важное напоминание

**Я тоже человек. Могу ошибаться или допускать ошибки.**
**Не торопитесь писать негативные отзывы — всегда можно всё исправить.**

---

Создано для Red1dark Studio | 2025
