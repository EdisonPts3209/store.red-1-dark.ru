# ⚡ Быстрый старт Red1dark Studio

## 1. Распаковка архива

```bash
tar -xzf red1dark-store.tar.gz
cd red1dark-store
```

## 2. Установка и запуск

### Вариант 1: Запуск всей платформы (веб + бот)

```bash
# Создать виртуальное окружение
python3 -m venv venv
source venv/bin/activate  # Linux/Mac
# или
venv\Scripts\activate  # Windows

# Установить зависимости
pip install -r requirements.txt
cd telegram_bot
pip install -r requirements.txt
cd ..

# Настроить Telegram бота
cd telegram_bot
cp config.py.example config.py
nano config.py  # Укажите токен бота и админ ID
cd ..

# Запустить платформу
./start.sh  # Linux/Mac
# или
start.bat  # Windows
```

### Вариант 2: Только веб-приложение

```bash
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
python app.py
```

### Вариант 3: Только Telegram бот

```bash
cd telegram_bot
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
cp config.py.example config.py
nano config.py  # Настройте
python bot.py
```

## 3. Открыть в браузере

http://localhost:5000

## 4. Демо-авторизация

**Покупатель:**
- Нажмите "Войти"
- Введите любой username
- Нажмите "Войти как покупатель"

**Продавец:**
- Нажмите "Войти"
- Нажмите "Войти как продавец"
- Откроется панель продавца

## 5. Основные URL

**Веб-приложение:**
- Главная: http://localhost:5000/
- Каталог: http://localhost:5000/services
- Корзина: http://localhost:5000/cart
- Профиль: http://localhost:5000/profile (после входа)
- Панель продавца: http://localhost:5000/seller (для продавца)

**Telegram бот:**
- Найдите бота в Telegram по username (указанному при создании)
- Отправьте /start для начала работы
- Используйте команды: /help, /services, /requests, /profile

## 6. Тестовые сценарии

### Как покупатель (веб):
1. Войдите как покупатель
2. Перейдите в каталог
3. Добавьте услуги в корзину
4. Перейдите в корзину
5. Оформите заявку
6. Посмотрите заявки в профиле

### Как покупатель (бот):
1. Напишите боту /start
2. Нажмите "🛍️ Каталог услуг"
3. Выберите услугу
4. Нажмите "✉️ Написать в боте"
5. Опишите задачу
6. Проверьте /requests

### Как продавец (веб):
1. Войдите как продавец
2. Откройте панель продавца
3. Посмотрите заявки
4. Измените статус заявки
5. Управляйте услугами
6. Посмотрите клиентов

### Как продавец (бот):
1. Напишите боту /start
2. Нажмите "🎛️ Панель админа"
3. Проверьте /stats для статистики
4. Используйте /allrequests для заявок
5. Попробуйте /broadcast для рассылки

## 7. Файлы данных

Все данные хранятся в папке `data/`:
- `users.json` - пользователи
- `services.json` - услуги
- `requests.json` - заявки
- `settings.json` - настройки

## 8. Для продакшена

📖 Смотрите подробные инструкции:
- `DEPLOYMENT.md` - развёртывание на REG.RU
- `OAUTH_SETUP.md` - настройка VK и Telegram OAuth
- `README.md` - полная документация

## ⚠️ Важно

**В демо-режиме:**
- OAuth упрощён (для продакшена нужен настоящий)
- Платежи не работают (требуется настройка)
- Данные сбрасываются при перезапуске (используйте JSON)

**Для продакшена:**
- Настройте OAuth (см. OAUTH_SETUP.md)
- Настройте платежи в банке
- Используйте базу данных (SQLite/PostgreSQL)
- Настройте SSL сертификат

## 📞 Нужна помощь?

Смотрите `README.md` для детальной информации.

---

❤️ Помните: я тоже человек, могу ошибаться. Всегда можно всё исправить!
