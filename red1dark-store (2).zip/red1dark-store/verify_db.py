"""
Скрипт проверки и верификации инициализированной базы данных.
"""

from datetime import datetime
from app import app, db
from models import User, Role, Permission, Service, Order, UserLog, AuthToken


def verify_database():
    """Полная проверка БД"""
    print('\n' + '='*70)
    print('🔍 ВЕРИФИКАЦИЯ БАЗЫ ДАННЫХ RED1DARK STUDIO')
    print('='*70 + '\n')
    
    with app.app_context():
        # 1. Проверяем роли
        print('📋 1. ПРОВЕРКА РОЛЕЙ:')
        roles = Role.query.all()
        print(f'   Всего ролей: {len(roles)}')
        expected_roles = {'guest': 1, 'buyer': 2, 'seller': 3, 'admin': 4, 'system_admin': 5, 'owner': 6}
        for role in roles:
            expected_level = expected_roles.get(role.name)
            level_ok = '✅' if role.level == expected_level else '❌'
            print(f'   {level_ok} {role.display_name} (level={role.level})')
        
        # 2. Проверяем права
        print(f'\n📋 2. ПРОВЕРКА ПРАВ:')
        permissions = Permission.query.all()
        print(f'   Всего прав: {len(permissions)}')
        
        # Группируем по категориям
        categories = {}
        for perm in permissions:
            cat = perm.category
            if cat not in categories:
                categories[cat] = []
            categories[cat].append(perm)
        
        for category, perms in sorted(categories.items()):
            print(f'   • {category}: {len(perms)} прав')
        
        # 3. Проверяем назначение прав ролям
        print(f'\n🔗 3. ПРОВЕРКА НАЗНАЧЕНИЯ ПРАВ:')
        for role in roles:
            print(f'   {role.display_name}: {len(role.permissions)} прав')
        
        # Проверяем иерархию: каждая роль должна иметь больше прав, чем предыдущая
        sorted_roles = sorted(roles, key=lambda r: r.level)
        perms_count = [len(r.permissions) for r in sorted_roles]
        is_ascending = all(perms_count[i] <= perms_count[i+1] for i in range(len(perms_count)-1))
        hierarchy_ok = '✅' if is_ascending else '❌'
        print(f'   {hierarchy_ok} Иерархия прав (возрастающая): {perms_count}')
        
        # 4. Проверяем владельца
        print(f'\n👑 4. ПРОВЕРКА ВЛАДЕЛЬЦА:')
        owner = User.query.filter_by(username='red1dark').first()
        if owner:
            print(f'   ✅ Владелец найден: {owner.username}')
            print(f'   📧 Email: {owner.email}')
            print(f'   🎖️ Роли: {", ".join(r.display_name for r in owner.roles)}')
            owner_role = owner.roles[0] if owner.roles else None
            if owner_role and owner_role.name == 'owner':
                print(f'   ✅ Роль владельца корректна')
                perms = len(owner_role.permissions)
                print(f'   📋 Всего прав: {perms}')
            else:
                print(f'   ❌ Роль владельца некорректна!')
        else:
            print(f'   ❌ Владелец не найден!')
        
        # 5. Проверяем методы модели User
        print(f'\n🛠️ 5. ПРОВЕРКА МЕТОДОВ МОДЕЛИ:')
        if owner:
            # has_role
            has_owner_role = owner.has_role('owner')
            has_buyer_role = owner.has_role('buyer')
            print(f'   ✅ has_role("owner"): {has_owner_role}')
            print(f'   ✅ has_role("buyer"): {has_buyer_role}')
            
            # has_permission
            has_admin_panel = owner.has_permission('view_admin_panel')
            print(f'   ✅ has_permission("view_admin_panel"): {has_admin_panel}')
            
            # get_role_level
            role_level = owner.get_role_level()
            print(f'   ✅ get_role_level(): {role_level}')
        
        # 6. Проверяем типы данных
        print(f'\n💾 6. ПРОВЕРКА ТИПОВ ДАННЫХ:')
        # Проверяем User.balance (должен быть Float/REAL)
        print(f'   ✅ User.balance (REAL для SQLite): {type(owner.balance).__name__}')
        # Проверяем User.created_at (должен быть String/TEXT)
        print(f'   ✅ User.created_at (TEXT для SQLite): {type(owner.created_at).__name__}')
        # Проверяем Service.price (должен быть Float/REAL)
        
        # 7. Статистика
        print(f'\n📊 7. СТАТИСТИКА БД:')
        users_count = User.query.count()
        services_count = Service.query.count()
        orders_count = Order.query.count()
        logs_count = UserLog.query.count()
        tokens_count = AuthToken.query.count()
        
        print(f'   👥 Пользователей: {users_count}')
        print(f'   🛍️ Услуг: {services_count}')
        print(f'   📦 Заказов: {orders_count}')
        print(f'   📝 Логов: {logs_count}')
        print(f'   🔑 Токенов: {tokens_count}')
        
        # 8. Тестирование методов
        print(f'\n🧪 8. ТЕСТИРОВАНИЕ МЕТОДОВ:')
        
        # Создаём тестовую роль buyer и проверяем права
        buyer = Role.query.filter_by(name='buyer').first()
        if buyer:
            can_create_order = buyer.has_permission('create_order')
            can_view_admin = buyer.has_permission('view_admin_panel')
            print(f'   ✅ Buyer.has_permission("create_order"): {can_create_order}')
            print(f'   ✅ Buyer.has_permission("view_admin_panel"): {can_view_admin}')
        
        print('\n' + '='*70)
        print('✅ ВЕРИФИКАЦИЯ ЗАВЕРШЕНА')
        print('='*70 + '\n')


if __name__ == '__main__':
    try:
        verify_database()
    except Exception as e:
        print(f'\n❌ ОШИБКА: {e}')
        import traceback
        traceback.print_exc()
