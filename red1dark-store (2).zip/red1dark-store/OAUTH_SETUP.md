# 🔐 Руководство по настройке OAuth интеграций (Финальная версия)

**Важно:** Клиент самостоятельно получает OAuth ключи. Разработчик только подключает их в код.

---

## 🔵 VK OAuth

### Шаг 1: Получение ключей (ДЕЛАЕТ КЛИЕНТ)

1. Перейдите на https://vk.com/apps (нужно войти в аккаунт ВК)
2. Нажмите **"Создать приложение"**
3. Заполните:
   - **Название:** Red1dark Studio
   - **Платформа:** Веб-приложение
   - **Адрес сайта:** `https://yourdomain.com`
   - **Redirect URI:** `https://yourdomain.com/auth/vk/callback`

4. Получите:
   - **ID приложения** (Client ID)
   - **Защищённый ключ** (Client Secret)

### Шаг 2: Добавление ключей в .env

```ini
VK_CLIENT_ID=your-vk-app-id
VK_CLIENT_SECRET=your-vk-secret-key
VK_REDIRECT_URI=https://yourdomain.com/auth/vk/callback
```

---

## 💙 TELEGRAM OAuth

### Вариант: Telegram Bot

1. Напишите [@BotFather](https://t.me/botfather) `/newbot`
2. Укажите имя: Red1dark Shop
3. Получите **Bot Token**
4. Команда `/setdomain`, укажите домен

### В .env:

```ini
TELEGRAM_BOT_TOKEN=123456789:ABCDefGhIjKlMnOpQrStUvWxYz
TELEGRAM_CLIENT_ID=your-app-id
```

---

## 🚀 Тестирование локально

Используйте **ngrok**:

```bash
ngrok http 5000
```

Скопируйте URL (например: `https://abc123.ngrok.io`) и обновите redirect URI в приложениях VK и Telegram.

---

## ⚠️ БЕЗОПАСНОСТЬ

### НЕ расшaривайте:
- ❌ Client Secret
- ❌ Bot Token
- ❌ App ID/Hash

### Правильно:
- ✅ Храните в `.env`
- ✅ Добавьте `.env` в `.gitignore`
- ✅ Передавайте только через защищённые каналы

---

## 📞 Помощь

- **Telegram:** [@red1dark](https://t.me/red1dark)
- **Email:** info@red-1-dark.ru

---

**Последнее обновление:** 7 февраля 2026
