"""
Скрипт инициализации базы данных для Red1dark Studio.
Создаёт структуру БД, роли, права и первого пользователя (owner).
"""

import os
import sys
from datetime import datetime
from werkzeug.security import generate_password_hash

# Импортируем Flask app и модели
from app import app, db
from models import User, Role, Permission


# Данные ролей (иерархия 1-6)
ROLES_DATA = [
    {
        'name': 'guest',
        'display_name': '👤 Гость',
        'icon': '👤',
        'level': 1,
        'description': 'Неавторизованный пользователь (только просмотр)'
    },
    {
        'name': 'buyer',
        'display_name': '🛒 Покупатель',
        'icon': '🛒',
        'level': 2,
        'description': 'Стандартный пользователь для покупки услуг'
    },
    {
        'name': 'seller',
        'display_name': '💼 Продавец',
        'icon': '💼',
        'level': 3,
        'description': 'Оказание услуг и управление заказами'
    },
    {
        'name': 'admin',
        'display_name': '🔧 Администратор',
        'icon': '🔧',
        'level': 4,
        'description': 'Управление модерацией и контентом'
    },
    {
        'name': 'system_admin',
        'display_name': '🛡️ Системный администратор',
        'icon': '🛡️',
        'level': 5,
        'description': 'Резервный уровень доступа для критических операций'
    },
    {
        'name': 'owner',
        'display_name': '👑 Владелец',
        'icon': '👑',
        'level': 6,
        'description': 'Полный контроль над системой'
    }
]


# Данные прав (permissions) по категориям
PERMISSIONS_DATA = [
    # Администрирование
    {
        'name': 'view_admin_panel',
        'display_name': '📋 Просмотр админ-панели',
        'category': 'admin',
        'description': 'Доступ к административной панели'
    },
    {
        'name': 'manage_users',
        'display_name': '👥 Управление пользователями',
        'category': 'admin',
        'description': 'Изменение данных пользователей'
    },
    {
        'name': 'manage_roles',
        'display_name': '🎖️ Управление ролями',
        'category': 'admin',
        'description': 'Выдача и отзыв ролей пользователям'
    },
    {
        'name': 'block_user',
        'display_name': '🚫 Блокировка пользователей',
        'category': 'admin',
        'description': 'Блокировка и разблокировка аккаунтов'
    },
    {
        'name': 'view_logs',
        'display_name': '📊 Просмотр логов',
        'category': 'admin',
        'description': 'Доступ к системным логам'
    },
    
    # Модерирование контента
    {
        'name': 'moderate_content',
        'display_name': '📝 Модерирование контента',
        'category': 'moderation',
        'description': 'Проверка и изменение контента'
    },
    {
        'name': 'moderate_requests',
        'display_name': '📋 Модерирование заявок',
        'category': 'moderation',
        'description': 'Просмотр и управление заявками'
    },
    
    # Работа с услугами
    {
        'name': 'view_all_services',
        'display_name': '🔍 Просмотр услуг',
        'category': 'content',
        'description': 'Просмотр каталога услуг'
    },
    {
        'name': 'create_service',
        'display_name': '➕ Создание услуг',
        'category': 'content',
        'description': 'Создание новых услуг'
    },
    {
        'name': 'edit_service',
        'display_name': '✏️ Редактирование услуг',
        'category': 'content',
        'description': 'Изменение услуг'
    },
    {
        'name': 'edit_own_service',
        'display_name': '✏️ Редактирование своих услуг',
        'category': 'content',
        'description': 'Изменение только своих услуг'
    },
    {
        'name': 'delete_service',
        'display_name': '🗑️ Удаление услуг',
        'category': 'content',
        'description': 'Удаление услуг'
    },
    
    # Заказы и заявки
    {
        'name': 'create_order',
        'display_name': '🛒 Создание заказов',
        'category': 'sales',
        'description': 'Создание заявок на услуги'
    },
    {
        'name': 'view_own_orders',
        'display_name': '👁️ Просмотр своих заказов',
        'category': 'sales',
        'description': 'Просмотр только своих заказов'
    },
    {
        'name': 'view_all_orders',
        'display_name': '👁️ Просмотр всех заказов',
        'category': 'sales',
        'description': 'Просмотр всех заказов системы'
    },
    {
        'name': 'manage_own_orders',
        'display_name': '⚙️ Управление своими заказами',
        'category': 'sales',
        'description': 'Изменение статуса своих заказов'
    },
    {
        'name': 'manage_all_orders',
        'display_name': '⚙️ Управление заказами',
        'category': 'sales',
        'description': 'Изменение всех заказов'
    },
    
    # Профиль и личные данные
    {
        'name': 'view_profile',
        'display_name': '👤 Просмотр профиля',
        'category': 'profile',
        'description': 'Просмотр своего профиля'
    },
    {
        'name': 'edit_profile',
        'display_name': '✏️ Редактирование профиля',
        'category': 'profile',
        'description': 'Изменение своего профиля'
    },
    {
        'name': 'view_seller_dashboard',
        'display_name': '🛍️ Панель продавца',
        'category': 'seller',
        'description': 'Доступ к панели продавца'
    },
    
    # Платежи и финансы
    {
        'name': 'view_analytics',
        'display_name': '📊 Просмотр аналитики',
        'category': 'sales',
        'description': 'Просмотр статистики и отчётов'
    },
]


def create_database():
    """Создаёт структуру БД"""
    print('📚 Создание таблиц БД...')
    with app.app_context():
        db.create_all()
    print('✅ Таблицы созданы')


def create_roles():
    """Создаёт роли"""
    print('🎖️ Создание ролей...')
    with app.app_context():
        for role_data in ROLES_DATA:
            existing = Role.query.filter_by(name=role_data['name']).first()
            if not existing:
                role = Role(
                    name=role_data['name'],
                    display_name=role_data['display_name'],
                    icon=role_data['icon'],
                    level=role_data['level'],
                    description=role_data['description']
                )
                db.session.add(role)
                print(f"  ✓ {role.display_name} (уровень {role.level})")
        
        db.session.commit()
    print('✅ Роли созданы')


def create_permissions():
    """Создаёт права доступа"""
    print('🔐 Создание прав доступа...')
    with app.app_context():
        for perm_data in PERMISSIONS_DATA:
            existing = Permission.query.filter_by(name=perm_data['name']).first()
            if not existing:
                perm = Permission(
                    name=perm_data['name'],
                    display_name=perm_data['display_name'],
                    category=perm_data['category'],
                    description=perm_data.get('description', '')
                )
                db.session.add(perm)
                print(f"  ✓ {perm.display_name}")
        
        db.session.commit()
    print('✅ Права доступа созданы')


def assign_permissions_to_roles():
    """Назначает права ролям согласно иерархии"""
    print('🔗 Назначение прав ролям...')
    with app.app_context():
        # Получаем роли и права
        guest_role = Role.query.filter_by(name='guest').first()
        buyer_role = Role.query.filter_by(name='buyer').first()
        seller_role = Role.query.filter_by(name='seller').first()
        admin_role = Role.query.filter_by(name='admin').first()
        system_admin_role = Role.query.filter_by(name='system_admin').first()
        owner_role = Role.query.filter_by(name='owner').first()
        
        # Права для гостя (только просмотр)
        guest_perms = ['view_all_services', 'view_profile']
        
        # Права для покупателя (всё что у гостя + создание заказов, профиль)
        buyer_perms = guest_perms + ['create_order', 'view_own_orders', 'edit_profile', 'view_profile']
        
        # Права для продавца (всё от buyer + управление заказами и услугами)
        seller_perms = buyer_perms + [
            'create_service', 'edit_own_service', 'manage_own_orders',
            'view_seller_dashboard', 'view_analytics'
        ]
        
        # Права для администратора (модерирование контента)
        admin_perms = seller_perms + [
            'view_admin_panel', 'moderate_content', 'moderate_requests',
            'edit_service', 'view_all_orders', 'manage_all_orders',
            'view_logs'
        ]
        
        # Права для системного администратора (всё кроме владельца)
        system_admin_perms = admin_perms + [
            'manage_users', 'manage_roles', 'block_user'
        ]
        
        # Права владельца (абсолютные)
        owner_perms = system_admin_perms  # Владелец имеет все права
        
        # Функция для присвоения прав
        def assign_perms(role, perm_names):
            for perm_name in perm_names:
                perm = Permission.query.filter_by(name=perm_name).first()
                if perm and perm not in role.permissions:
                    role.permissions.append(perm)
                    print(f"  ✓ {role.display_name} ← {perm.display_name}")
        
        # Присваиваем права ролям
        if guest_role:
            assign_perms(guest_role, guest_perms)
        if buyer_role:
            assign_perms(buyer_role, buyer_perms)
        if seller_role:
            assign_perms(seller_role, seller_perms)
        if admin_role:
            assign_perms(admin_role, admin_perms)
        if system_admin_role:
            assign_perms(system_admin_role, system_admin_perms)
        if owner_role:
            assign_perms(owner_role, owner_perms)
        
        db.session.commit()
    print('✅ Права назначены')


def create_owner_user():
    """Создаёт первого пользователя с ролью владельца"""
    print('👑 Создание пользователя-владельца...')
    with app.app_context():
        # Проверяем, есть ли уже владелец
        existing_owner = User.query.join(User.roles).filter(Role.name == 'owner').first()
        if existing_owner:
            print(f'⚠️ Владелец уже существует: {existing_owner.username}')
            return
        
        # Получаем роль владельца
        owner_role = Role.query.filter_by(name='owner').first()
        if not owner_role:
            print('❌ Роль "owner" не найдена!')
            return
        
        # Создаём пользователя
        owner_user = User(
            email='red1dark@red-1-dark.ru',
            username='red1dark',
            name='Red1dark',
            password_hash=generate_password_hash('change-me-in-production'),
            is_active=True,
            email_verified=True,
            is_seller=True,
            balance=0.0,
            created_at=datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            updated_at=datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        )
        
        # Назначаем роль
        owner_user.roles.append(owner_role)
        
        db.session.add(owner_user)
        db.session.commit()
        
        print(f'✅ Владелец создан:')
        print(f'   Email: {owner_user.email}')
        print(f'   Username: {owner_user.username}')
        print(f'   Роль: {owner_role.display_name}')
        print(f'   ⚠️ Измените пароль в продакшене!')


def init_database():
    """Полная инициализация базы данных"""
    print('\n' + '='*60)
    print('🚀 ИНИЦИАЛИЗАЦИЯ БАЗЫ ДАННЫХ RED1DARK STUDIO')
    print('='*60 + '\n')
    
    try:
        create_database()
        create_roles()
        create_permissions()
        assign_permissions_to_roles()
        create_owner_user()
        
        print('\n' + '='*60)
        print('✅ ИНИЦИАЛИЗАЦИЯ ЗАВЕРШЕНА УСПЕШНО!')
        print('='*60 + '\n')
        
    except Exception as e:
        print(f'\n❌ ОШИБКА ИНИЦИАЛИЗАЦИИ: {e}')
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == '__main__':
    init_database()
