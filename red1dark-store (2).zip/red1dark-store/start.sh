#!/bin/bash

# Скрипт для запуска Red1dark Studio (веб-приложение + Telegram бот)

echo "🚀 Запуск Red1dark Studio..."
echo ""

# Проверка виртуального окружения
if [ ! -d "venv" ]; then
    echo "❌ Виртуальное окружение не найдено!"
    echo "Создайте его командой: python3 -m venv venv"
    exit 1
fi

# Активация виртуального окружения
source venv/bin/activate

# Проверка установки зависимостей
echo "📦 Проверка зависимостей..."
pip install -r requirements.txt > /dev/null 2>&1
cd telegram_bot
pip install -r requirements.txt > /dev/null 2>&1
cd ..

# Создание папки data если не существует
mkdir -p data

echo "✅ Подготовка завершена"
echo ""

# Запуск веб-приложения в фоне
echo "🌐 Запуск веб-приложения на http://localhost:5000"
python app.py &
WEB_PID=$!

# Небольшая пауза
sleep 2

# Запуск Telegram бота в фоне
echo "🤖 Запуск Telegram бота"
cd telegram_bot
python bot.py &
BOT_PID=$!
cd ..

echo ""
echo "✅ Платформа запущена!"
echo ""
echo "📊 Процессы:"
echo "   Веб-приложение: PID $WEB_PID"
echo "   Telegram бот:   PID $BOT_PID"
echo ""
echo "🌐 Веб-приложение: http://localhost:5000"
echo "🤖 Telegram бот:   Проверьте в Telegram"
echo ""
echo "❌ Для остановки нажмите Ctrl+C"
echo ""

# Функция для остановки всех процессов
cleanup() {
    echo ""
    echo "🛑 Остановка платформы..."
    kill $WEB_PID 2>/dev/null
    kill $BOT_PID 2>/dev/null
    echo "✅ Платформа остановлена"
    exit 0
}

# Обработка Ctrl+C
trap cleanup SIGINT SIGTERM

# Ожидание
wait
